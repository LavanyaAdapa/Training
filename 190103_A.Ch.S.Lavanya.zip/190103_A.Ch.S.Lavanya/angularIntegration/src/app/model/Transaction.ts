export class transactiondetails{
    transactionid:number;                       
    baccount:number; 
    initialbalance:number;                                  
    transactionmethod:string;
    finalbalance:number;
    transdate:Date;
     constructor(transactionid:number,baccount:number,initialbalance:number,transactionmethod:string,finalbalance:number, transdate:Date)  //default constructor
       {
        this.transactionid=transactionid;
        this.baccount=baccount;
        this.initialbalance=initialbalance;
        this.transactionmethod=transactionmethod;
        this.finalbalance=finalbalance;
        this.transdate=transdate;
        }
  }