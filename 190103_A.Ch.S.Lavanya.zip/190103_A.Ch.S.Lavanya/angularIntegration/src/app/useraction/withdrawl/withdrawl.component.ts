import { Component, OnInit } from '@angular/core';
import { ServicelayerService } from 'src/app/servicelayer.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-withdrawl',
  templateUrl: './withdrawl.component.html',
  styleUrls: ['./withdrawl.component.css']
})
export class WithdrawlComponent implements OnInit {

  servicelayer:ServicelayerService;
  router:Router;
  constructor( servicelayer:ServicelayerService,router:Router) 
  {this.servicelayer=servicelayer,this.router=router }
  
  
  withdraw(data:any){
   let a= this.servicelayer.withdraw(data.accountnumber,data.password,data.withdrawbalance)
    a.subscribe((data) =>{
      alert("After withdraw balance is "+data);
      this.router.navigate(['useraction']);
    },(error) =>{
      alert("enter correct details")
  this.router.navigate(['useraction']);
    }) 
  }
  ngOnInit() {
  }

}
