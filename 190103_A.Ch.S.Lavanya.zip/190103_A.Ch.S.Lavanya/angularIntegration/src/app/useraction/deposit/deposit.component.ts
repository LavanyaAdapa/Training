import { Component, OnInit } from '@angular/core';
import { ServicelayerService } from 'src/app/servicelayer.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {
  servicelayer:ServicelayerService;
  router:Router;
  constructor(  servicelayer:ServicelayerService,router:Router) { 
    this.servicelayer=servicelayer;this.router=router;
  }

  deposit(data:any)
  {
    let a= this.servicelayer.deposit(data.accountnumber,data.password,data.depositbalance);
    a.subscribe((data) =>{
      alert("After Deposited balance is "+data);
      this.router.navigate(['useraction']);
    },(error) =>{
      alert("enter correct details")
      this.router.navigate(['useraction']);
    })
  }
  ngOnInit() {
  }

}
