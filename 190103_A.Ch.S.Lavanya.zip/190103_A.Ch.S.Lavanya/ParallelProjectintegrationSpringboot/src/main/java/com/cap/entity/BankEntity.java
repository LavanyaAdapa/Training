package com.cap.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="bank_project_integration")
public class BankEntity {
	@Id
	private Long bacc;
	@NotBlank(message="name is Required")
	private String bname;
	@NotBlank(message="Number is Required")
	private String bnum2;
	@NotBlank(message="DateOfBirth is Required")
	private String bdob;
	@NotBlank(message="Password is Required")
	private String bpass;
	@NotNull(message="Intial Balance is Required")
	@Min(value=50 ,message="Minimum Balance is : 50")
	private Integer bbal;
	@NotBlank(message="AccountType is Required")
	private String actype;
	@NotBlank(message="location is Required")
	private String location;
	
//	@GeneratedValue(strategy=GenerationType.AUTO,generator="qwer")
//	@SequenceGenerator(name="qwer",sequenceName="Sqn")
//	CREATE SEQUENCE sequence_name
//	START WITH initial_value
//	INCREMENT BY increment_value
//	MINVALUE minimum value
//	MAXVALUE maximum value
//	CYCLE|NOCYCLE ;
	
	
	@Override
	public String toString() {
		return "Account Details [bacc=" + bacc + ", bname=" + bname + ", bnum2=" + bnum2 + ", bdob=" + bdob + ", bpass="
				+ bpass + ", bbal=" + bbal + ", actype=" + actype + ", location=" + location + "]";
	}

	
	public Long getBacc() {
		return bacc;
	}

	public void setBacc(Long bacc) {
		this.bacc = bacc;
	}

	public String getBname() {
		return bname;
	}

	public void setBname(String bname) {
		this.bname = bname;
	}

	public String getBnum2() {
		return bnum2;
	}

	public void setBnum2(String bnum2) {
		this.bnum2 = bnum2;
	}

	public String getBdob() {
		return bdob;
	}

	public void setBdob(String bdob) {
		this.bdob = bdob;
	}

	public String getBpass() {
		return bpass;
	}

	public void setBpass(String bpass) {
		this.bpass = bpass;
	}

	public Integer getBbal() {
		return bbal;
	}

	public void setBbal(Integer bbal) {
		this.bbal = bbal;
	}

	public String getActype() {
		return actype;
	}

	public void setActype(String actype) {
		this.actype = actype;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
	

	
	

}
