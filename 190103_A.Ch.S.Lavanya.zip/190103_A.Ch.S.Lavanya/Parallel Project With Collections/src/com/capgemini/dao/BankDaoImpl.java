package com.capgemini.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.capgemini.exception.InsufficientBalanceException;
import com.capgemini.model.Account;

public class BankDaoImpl implements BankDao 
{
	
	static List<Account> al=new ArrayList();
	static
	{
		Account a1=new Account("448454842146", "Lavanya", "9010634343", "656469446433",10000,"4040");
		Account a2=new Account("484548421445", "Purna", "9649423458", "656469446253", 11000,"4045");
		Account a3=new Account("587953298121", "Sai", "9586845456", "145678964578", 15000,"4654");
		al.add(a1);
		al.add(a2);
		al.add(a3);
	}
	public String dateAndTime()
	{
		DateFormat dAndT=new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Date d=new Date();
		return dAndT.format(d);
	}
	@Override
	public boolean saveAccount(Account a) 
	{
		return al.add(a);
	}

	@Override
	public long viewBalance(String accountNo, String pin) 
	{
		Iterator<Account> itr=al.iterator();
		Account a=null;
		String acNo;
		long acBal;
		while(itr.hasNext())
		{
			a=itr.next();
			if(a.getAccountNo().contentEquals(accountNo) && a.getPin().contentEquals(pin))
			{
				return a.getAccountBalance();
			}
		}
		return -1;
	}

	@Override
	public long depositCash(String accountNo,long amount) {
		Iterator<Account> itr=al.iterator();
		while(itr.hasNext())
		{
			Account a=itr.next();
			if(a.getAccountNo().equals(accountNo))
			{
				a.setAccountBalance(a.getAccountBalance()+amount);
				a.tl.add(dateAndTime()+" Deposit      "+amount+"       "+a.getAccountBalance());
				return a.getAccountBalance();
			}
		}
		
		return -1;
	}

	@Override
	public long withdrawCash(String accountNo, String pin,long amount) throws InsufficientBalanceException {
		Iterator<Account> itr=al.iterator();
		while(itr.hasNext())
		{
			Account a=itr.next();
			if(a.getAccountNo().equals(accountNo) && a.getPin().equals(pin))
			{
				if(a.getAccountBalance()>=amount)
				{
				  a.setAccountBalance(a.getAccountBalance()-amount);
				  a.tl.add(dateAndTime()+" Withdraw     "+amount+"       "+a.getAccountBalance());
				  return a.getAccountBalance();
				}
				else throw new InsufficientBalanceException("Insufficient Balance");
			}
		}
		return -1;
	}

	@Override
	public boolean tranferMoney(String sourceAcNo, String destAcNo, long amount,String pin) throws InsufficientBalanceException {
		Iterator<Account> itr=al.iterator();
		while(itr.hasNext())
		{
			Account a=itr.next();
			if(a.getAccountNo().equals(sourceAcNo) && a.getPin().equals(pin))
			{
				if(a.getAccountBalance()>=amount)
				{
				 a.setAccountBalance(a.getAccountBalance()-amount);
				 a.tl.add(dateAndTime()+" Transfer      "+amount+"       "+a.getAccountBalance());
				 return true;
				}
				else throw new InsufficientBalanceException("Insufficient Balance");
					
			}
 		}
		return false;
	}

	@Override
	public List<String> showTransactions(String accountNo,String pin) 
	{
		Account a=null;
		Iterator<Account> itr=al.iterator();
		while(itr.hasNext())
		{
			a=itr.next();
			if(a.getAccountNo().equals(accountNo) && a.getPin().equals(pin))
				break;
			
		}
		return a.tl;
	}
}
