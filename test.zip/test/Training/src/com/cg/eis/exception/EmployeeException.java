package com.cg.eis.exception;
class InvalidSalaryException extends Exception
{
	InvalidSalaryException(String str)
	{
		super(str);
	}
}
public class EmployeeException {
static void valid(int Salary) throws InvalidSalaryException
{
	if(Salary<3000)
	{
		System.out.println("Not Valid");
	}
	else 
		System.out.println("Valid Salary");
}
public static void main(String args[])
{
	try{
	valid(5000);	
	}
	catch(Exception e)
	{
		System.out.println("Exception Occured");
	}
}
}
