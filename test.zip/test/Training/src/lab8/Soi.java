package lab8;
import java.util.*;
import java.util.Scanner;
public class Soi {
public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the numbers:");
	String ob=sc.next();
	StringTokenizer st=new StringTokenizer(ob,"*");
	int sum=0;
	while(st.hasMoreTokens())
	{
		int n=0;
		n=Integer.parseInt(st.nextToken());
		System.out.println(n);
		sum=sum+n;
	}
	System.out.println(sum);
	sc.close();
}

}
