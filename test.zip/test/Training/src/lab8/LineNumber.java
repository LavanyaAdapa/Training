package lab8;
import java.util.*;
import java.io.*;
public class LineNumber {
	public static void main(String args[]) throws IOException
    {
        int a=1;
        char c;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the file name:");
       
       
        String str=sc.next();
        FileInputStream f=new FileInputStream(str);
       
        System.out.println("\nContents in the file are:");
       
        int n=f.available();
        System.out.println(a+":");
        for(int i=0;i<n;i++)
        {
            c=(char)f.read();
           
            System.out.println(c);
            if(c=='\n')
            {
                System.out.println(++a+":");
            }
        }
    }
}
