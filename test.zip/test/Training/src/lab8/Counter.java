package lab8;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileInputStream;
import java.io.IOException;
public class Counter {
public static void main(String args[]) throws IOException
{
	FileReader fr=new FileReader("f1.txt");
	BufferedReader br=new BufferedReader(fr);
	int charCount=0;
	int wordCount=0;
	int lineCount=0;
	String str;
	while((str=br.readLine())!=null)
	{
		lineCount++;
		String str1[]=str.split("");
		wordCount=wordCount+str1.length;
		for(String str3:str1)
		{
			charCount=charCount+str3.length();
			
		}
	}
		
	System.out.println("line Count"+lineCount);
	System.out.println("word Count"+wordCount);
	System.out.println("char count"+charCount);
	}	
}

