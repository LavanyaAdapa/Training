package lab8;
import java.util.Arrays;
import java.util.Scanner;
public class Positve {
static boolean isAlphabeticOrder(String str)
{
	int n=str.length();
	char c[]=new char[n];
	for(int i=0;i<n;i++)
	{
		c[i]=str.charAt(i);
	}
	Arrays.sort(c);
	for(int i=0;i<n;i++)
		if(c[i]!=str.charAt(i))
			return false;
		return true;
	
}

	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter String:");
		String str=sc.nextLine();
		if(isAlphabeticOrder(str))
			System.out.println("yes");
		else
			System.out.println("No");
}
}
