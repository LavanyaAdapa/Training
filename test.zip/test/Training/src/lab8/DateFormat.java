package lab8;
import java.text.SimpleDateFormat;
import java.util.Date;
public class DateFormat {
public DateFormat(String str)
{	
}
public static void main(String args[])
{
	Date d=new Date();
	System.out.println(d);
	SimpleDateFormat sdf1=new SimpleDateFormat("dd-mm-yyyy");
	System.out.println(sdf1.format(d));
	SimpleDateFormat sdf2=new SimpleDateFormat("HH-MM-SS");
	System.out.println(sdf2.format(d));
}
private char[] DateFormat(Date d)
{
	return null;
}
}
