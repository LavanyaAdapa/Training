package lab10;
import java.io.*;
public class CopyDataThread implements Runnable{
	public void run()
	{
		FileReader f=null;
		FileWriter f1=null;
		BufferedReader br=null;
		BufferedWriter bw=null;
		String line="";
		try
		{
			f=new FileReader("Source.txt");
			f1=new FileWriter("Targt.txt",true);
			br=new BufferedReader(f);
			bw=new BufferedWriter(f1);
			line=br.readLine();
			while(line!=null)
			{
				System.out.println(line);
				bw.write(line.toString());
				bw.flush();
				line= br.readLine();
			}
			f1.close();
		
		
		}
	catch(Exception e)
	{
		System.out.println(e);
	}
}
public static void main(String args[])
{
	CopyDataThread ob=new CopyDataThread();
	Thread t=new Thread(ob);
	t.start();
}
}

