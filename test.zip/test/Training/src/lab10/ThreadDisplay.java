package lab10;

public class ThreadDisplay implements Runnable {
	int count=0;
	public void run()
	{
		while(true)
		{
			System.out.println("Timer"+count+"Seconds");
			try
			{
				Thread.sleep(1000);
				count++;
				if(count==11)
				{
					System.out.println("Timer Reset");
					count=0;
				}
			}
			catch(InterruptedException ie)
			{
			ie.printStackTrace();	
			}
		}
	}
public static void main(String args[])
{
	ThreadDisplay td=new ThreadDisplay();
	Thread t1=new Thread(td);
	t1.start();
}
}
