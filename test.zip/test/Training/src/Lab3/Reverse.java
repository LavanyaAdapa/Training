package Lab3;
import java.util.Scanner;
public class Reverse {
	public static void main(String args[])
	{
		int i;
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b[]=new int[a];
		for(i=0;i<a;i++)
		{
			b[i]=sc.nextInt();
		}
		Reverse rs=new Reverse();
		int sort[]=rs.getSorted(b,a);
		for(i=0;i<sort.length;i++)
		{
			System.out.println(sort[i]);
		}
	}
	private int[] getSorted(int b[],int a)
	{
		int i,x=0;
		int y=0;
		int z=0;
		for(i=0;i<a;i++)
		{
			z=b[i];
			y=0;
			while(z!=0)
			{
				x=z%10;
				y=y*10+x;
				z=z/10;
			}
			b[i]=y;
		}
		for(i=0;i<a;i++)
		{
			for(int j=0;j<a;j++)
			{
				if(b[i]<b[j])
				{
					int temp=b[i];
					b[i]=b[j];
					b[j]=temp;
				}
			}
		}
		return b;
	}
}
