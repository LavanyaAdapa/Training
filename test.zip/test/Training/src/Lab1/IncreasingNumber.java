package Lab1;
import java.util.Scanner;
public class IncreasingNumber {
public boolean checkNumber(int number)
{
	while(number>0)
	{
		int value1=number%10;
		number=number/10;
		int value2=number%10;
		if(value1<value2)
		{
			return false;
		}
	}
		return true;
	}
	public static void main(String args [])
	{
		Scanner sc=new Scanner(System.in);
		int number=sc.nextInt();
		IncreasingNumber in=new IncreasingNumber();
		System.out.println(in.checkNumber(number));
		System.out.println(in instanceof IncreasingNumber);
	}
}
