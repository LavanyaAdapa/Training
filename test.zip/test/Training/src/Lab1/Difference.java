package Lab1;

public class Difference {
static int calculateDifference(int n)
{
	int sum=0,i,a,b;
	for(i=1;i<=n;i++)
	{
		sum=sum+(i*i);
         a=sum;
		b=sum*sum;
		sum=b-a;
	}
	return sum;
}
public static void main(String args[])
{
	System.out.println(calculateDifference(5));
}
}