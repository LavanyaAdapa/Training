package lab2;

public abstract class Item {
private int itemId;
private String title;
private int numberOfCopy;
public Item(int itemid,String title,int numberofCopy)
{
	this.itemId=itemId;
	this.title=title;
	this.numberOfCopy=numberOfCopy;
}
public int getItemId() {
	return itemId;
}
public void setItemId(int itemId) {
	this.itemId = itemId;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public int getNumberOfCopy() {
	return numberOfCopy;
}
public void setNumberOfCopy(int numberOfCopy) {
	this.numberOfCopy = numberOfCopy;
}
@Override
public String toString()
{
return "ItemDetails[itemid="+ itemId+",title="+title+",numberOfCopy="+numberOfCopy+"]";	
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Item other = (Item) obj;
	if (itemId != other.itemId)
		return false;
	if (numberOfCopy != other.numberOfCopy)
		return false;
	if (title == null) {
		if (other.title != null)
			return false;
	} else if (!title.equals(other.title))
		return false;
	return true;
}
public void checkIn(){}
public void checkOut(){}
public void addItem(){}
}
     abstract class WrittenItem extends Item
{
    
	private String authorName;
	public String getAuthorName()
	{
		return authorName;		
	}
	public void setAuthorName(String authorName)
	{
		this.authorName=authorName;
	}
	public WrittenItem(int itemId,String title,int numberOfCopy,String authorName)
	{
		super(itemId,title,numberOfCopy);
	}
}
abstract class Book extends WrittenItem
{
	public Book(int itemId,String title,int numberOfCopy,String authorName)
	{
		super(itemId,title,numberOfCopy,authorName);
	}
}

   abstract class JournalPaper extends WrittenItem
{
	private int year;
	public JournalPaper(int itemId,String title,int numberOfCopy,String authorName,int year)
	{
		super(itemId,title,numberOfCopy,authorName);
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
}
	abstract class MediaItem extends Item
	{
		private int number;
		public MediaItem(int itemId,String title,int numberOfCopy,int number)
		{
			super(itemId,title,numberOfCopy);
		}
		public int getNumber()
		{
			return number;
		}
		public void setNumber(int number)
		{
			
				this.number=number;
			}
		}
	abstract class Video extends MediaItem
	{
		private String director;
		private String genre;
		private int year;
		public Video(int itemId,String title,int numberOfCopy,int number,String director,String genre,int year)
		{
			super(itemId,title,numberOfCopy,number);
		}
		public String getDirector() {
			return director;
		}
		public void setDirector(String director) {
			this.director = director;
		}
		public String getGenre() {
			return genre;
		}
		public void setGenre(String genre) {
			this.genre = genre;
		}
		public int getYear() {
			return year;
		}
		public void setYear(int year) {
			this.year = year;
		}
		
	}
	abstract class CD extends MediaItem
	{
		private String artist;
		private String genre;
		public CD(int itemId,String title,int numberOfCopy,int number,String artist,String genre)
		{
			super(itemId,title,numberOfCopy,number);
		}
		public String getArtist() {
			return artist;
		}
		public void setArtist(String artist) {
			this.artist = artist;
		}
		public String getGenre() {
			return genre;
		}
		public void setGenre(String genre) {
			this.genre = genre;
		}
		
	}
