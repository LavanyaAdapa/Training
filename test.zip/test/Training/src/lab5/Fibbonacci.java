package lab5;
import java.util.Scanner;
public class Fibbonacci {
int a=1,b=1,c=0;
int count;
int nonRec(int a)
{
	count=a;
	count=recursive(count);
	return count;
}
int recursive(int count)
{
	if(count!=2)
	{
		c=a+b;
		a=b;
		b=c;
		recursive(--count);
	}
	return c;
}
public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	int a=sc.nextInt();
	Fibbonacci sc1=new Fibbonacci();
	int b=sc1.nonRec(a);
	System.out.println("Series is"+b);
	sc.close();
	
}
}
