package lab5;
import java.util.Scanner;
class InvalidAgeException extends Exception
{
	public InvalidAgeException(String str)
	{
	System.out.println(str);
	}

public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter age :");
	int age=sc.nextInt();
	try
	{
		if(age<15)
		{
			throw new InvalidAgeException("Invalid Age");
	}
		else
			System.out.println("Valid Age");
	}

	catch(InvalidAgeException e)
	{
		System.out.println("invalidException occured"+e);
	}
}
}