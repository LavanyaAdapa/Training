package lab5;
import java.util.Scanner;
public class EmployeeValidation extends Exception{
	public EmployeeValidation(String args)
	{
		System.out.println(args);
	}
public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the First Name:");
	String firstName=sc.nextLine();
	System.out.println("Enter the Last Name");
	String lastName=sc.nextLine();
	try
	{
		if(!firstName.equals(" ") && !lastName.equals(" "))
		{
			System.out.println("Enter First Name:");
			System.out.println(firstName);
			System.out.println("Enter Last Name");
			System.out.println(lastName);
		}
		else
		{
			throw new EmployeeValidation("Firstname and Lastname cannot be empty");
		}
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
}
}
