package lab13;

import lab13.Employee.EmployeeDetails;

public class LambdaExpresson4 {
	public static void main(String[] args)
    {
        EmployeeDetails e=Employee :: new;
        Employee ed=e.getEmployee("hello",1);
        System.out.println("Employee name:"+ed.getName());
        System.out.println("Employee Id: "+ed.getEmid());
    }
}
class Employee
{
    String name;
    int empid;
    public String getName()
    {
        return name;
    }
    public void setName(String name)
    {
        this.name=name;
    }
    public int getEmid()
    {
        return empid;
    }
    public Employee(String name,int emid)
    {
        this.name=name;
        this.empid=emid;
    }
    interface EmployeeDetails
    {
        public Employee getEmployee(String name,Integer emid);  
    }
  
}
