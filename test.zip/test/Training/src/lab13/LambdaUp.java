package lab13;
import java.util.Scanner;
import java.util.Comparator;
interface lambda1
{
	public boolean print(String a,String b);
}
public class LambdaUp {
public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	String name=sc.next();
	
	String password=sc.next();
	
	lambda1 l=(a,b)->{if(a.equals(name)&&b.equals(password))
		return true;
	else return false;
	};
	boolean c=l.print("Lavanya","760");
	System.out.println(c);
	sc.close();
}
}
