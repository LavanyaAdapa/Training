package lab13;
import java.util.function.Function;
public class LambdaFactorial {
public static void main(String args[])
{
	LambdaFactorial lf=new LambdaFactorial();
	Function<Integer,Integer>h=lf::fact;
	int y=h.apply(5);
	System.out.println(y);
}
public int fact(int x)
{
	int f=1;
	for(int i=1;i<=x;i++)
	{
		f=f*i;
	}
	return f;
}
}
