package lab13;
import java.util.*;
interface PowerOf
{
	public int cal(int x,int y);
}
public class Power {
public static void main(String args[])
{
	PowerOf p=(x,y)->{
		int res=1;
		for(int i=1;i<=y;i++)
			res=res*x;
		return res;
	};
	int res=p.cal(4,5);
	System.out.println(res);
			
}
}
