package lab9;
import java.io.*;
import java.util.*;
public class OccurenceOfChar {
static void countCharacter(String a)
{
	HashMap<Character,Integer> charCountMap=new HashMap<Character,Integer>();
	char[] StrArray=a.toCharArray();
	for(char ch: StrArray)
	{
		if(charCountMap.containsKey(ch))
		{
			charCountMap.put(ch,  charCountMap.get(ch)+1);
		}
		else
		{
			charCountMap.put(ch,1);
		}
	}
	for(Map.Entry entry :charCountMap.entrySet())
	{
		System.out.println(entry.getKey()+""+entry.getValue());
	}
}
public static void main(String args[])
{
	String str="Sailaja";
	countCharacter(str);
}
}
