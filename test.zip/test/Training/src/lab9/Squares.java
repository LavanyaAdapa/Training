package lab9;
import java.util.*;
import java.util.Scanner;
public class Squares {
public static HashMap<Integer,Integer> getSquares(int []a,int n)
{
	HashMap<Integer,Integer>map=new HashMap<Integer,Integer>();
	for(int b:a)
	{
		map.put(b, b*b);
	}
	return map;
}
public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Number of Elements ");
	int n=sc.nextInt();
	System.out.println("Enter numbers ");
	int[]a=new int[n];
	for(int j=0;j<n;j++)
	{
		a[j]=sc.nextInt();
	}
	HashMap<Integer,Integer>map=getSquares(a,n);
	Iterator<Integer>it=map.keySet().iterator();
	while(it.hasNext())
	{
		Integer key=it.next();
		System.out.println(key +";"+map.get(key));
	}
}
}
