package lab9;
import java.util.*;
import java.lang.*;
public class SortedOrder {
public static HashMap<String,Integer> getValues(HashMap<String,Integer>hm)
{
	List<Map.Entry<String,Integer>>list=new LinkedList<Map.Entry<String, Integer>>(hm.entrySet());
	Collections.sort(list,new Comparator<Map.Entry<String,Integer>>()
	{
		public int compare(Map.Entry<String,Integer>o1,Map.Entry<String,Integer>o2)
		{
			return(o1.getValue()).compareTo(o2.getValue());
		}
	}
	);
	HashMap<String,Integer> temp=new LinkedHashMap<String,Integer>();
	for(Map.Entry<String,Integer>aa:list)
	{
		temp.put(aa.getKey(),aa.getValue());
	}
	return temp;
}
public static void main(String args[])
{
	HashMap<String,Integer>hm=new HashMap<String,Integer>();
	hm.put("arnav",54);
	hm.put("anvi",76);
	hm.put("vihan",44);
	hm.put("sam",69);
	Map<String,Integer>hm1=getValues(hm);
	for(Map.Entry<String,Integer>en:hm1.entrySet())
	{
		System.out.println("Key="+en.getKey()+"Value="+en.getValue());
	}
}
}


