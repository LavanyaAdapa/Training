package practiceQue;

import java.util.HashMap;
import java.util.Scanner;

public class Question6 {
public static void main(String args[])
{
	HashMap<Integer,String>map=new HashMap<Integer,String>();
	map.put(1,"harry");
	map.put(2,"peter");
	map.put(3,"john");
	map.put(4,"jain");
	Scanner scanner=new Scanner(System.in);
	System.out.println("Enter the key you want to cheack");
	int key=scanner.nextInt();
	if(map.containsKey(key))
	{
		System.out.println(key);
	}
	else
	{
		System.out.println("Key is not available");
	}
}
}
