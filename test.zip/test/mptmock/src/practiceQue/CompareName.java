package practiceQue;

import java.util.Comparator;

public class CompareName implements Comparator<Customer> {
	    public int compare(Customer c1, Customer c2) {
	        return c1.getCustomername().compareTo(c2.getCustomername());
	    }
	    
	}

