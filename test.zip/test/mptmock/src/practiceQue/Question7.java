package practiceQue;

import java.util.*;
import java.util.Map.Entry;

public class Question7 {
public static void main(String args[])
{
	Scanner scanner=new Scanner(System.in);
Hashtable<Integer,String>hashtable=new Hashtable<Integer,String>();
System.out.println("Enter the elements to add:");
int choice=scanner.nextInt();
for(int i=0;i<choice;i++)
{
	int id=scanner.nextInt();
	String name=scanner.next();
	hashtable.put(id,name);
}
Set<Entry<Integer,String>>set=hashtable.entrySet();
Iterator<Entry<Integer,String>>iterator=set.iterator();
while(iterator.hasNext())
{
	Entry<Integer,String>entry=iterator.next();
	System.out.println(entry);
}
}
}
