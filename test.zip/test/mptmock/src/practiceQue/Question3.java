package practiceQue;

import java.util.HashMap;
import java.util.Scanner;
public class Question3 {
	public static void main(String args[])
	{
	
	
	 Scanner scanner=new Scanner(System.in);
     HashMap<Integer,CustomerValues>map=new HashMap<Integer,CustomerValues>();
     /*CustomerNumber customerNumber1=new CustomerNumber(3);
     CustomerNumber customerNumber2=new CustomerNumber(1);
     CustomerNumber customerNumber3=new CustomerNumber(4);*/
     System.out.println("Enter customer id to be diplayed");
     int customerId=scanner.nextInt();
     if(map.get(customerId)!=null)
      System.out.println(map.get(customerId));
     
     
     map.put(1,new CustomerValues(1,"sanju","chennai",12345));
     map.put(2,new CustomerValues(2,"anusha","kakinada",1234));
     
     System.out.println(map);
     
}

}