package practiceQue;


	import java.io.Serializable;

	 

	public class CustomerDetails1 implements  Serializable {
	    private static final long serialVersionUID = 1L;
	    public int customerId;
	    public String customerName;
	    public long phoneNO;
	    public void customerDetails(){
	        
	    }
	    public CustomerDetails1(int customerId, String customerName, long phoneNO) {
	        super();
	        this.customerId = customerId;
	        this.customerName = customerName;
	        this.phoneNO = phoneNO;
	    }
	    public int getCustomerId() {
	        return customerId;
	    }
	    public void setCustomerId(int customerId) {
	        this.customerId = customerId;
	    }
	    public String getCustomerName() {
	        return customerName;
	    }
	    public void setCustomerName(String customerName) {
	        this.customerName = customerName;
	    }
	    public long getPhoneNO() {
	        return phoneNO;
	    }
	    public void setPhoneNO(long phoneNO) {
	        this.phoneNO = phoneNO;
	    }
	    @Override
	    public String toString() {
	        return "CustomerDetails1 [customerId=" + customerId + ", customerName=" + customerName + ", phoneNO=" + phoneNO
	                + "]";
	    }
	    
	}

