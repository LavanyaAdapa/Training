package practiceQue;
import java.util.Comparator;
public class CustomerValues 
 {
public int customerId;
public String customername;
public String city;
public int mobileNo;
public CustomerValues(int customerId, String customername, String city, int mobileNo) {
	super();
	this.customerId = customerId;
	this.customername = customername;
	this.city = city;
	this.mobileNo = mobileNo;
}
public int getCustomerId() {
	return customerId;
}
public void setCustomerId(int customerId) {
	this.customerId = customerId;
}
public String getCustomername() {
	return customername;
}
public void setCustomername(String customername) {
	this.customername = customername;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public int getMobileNo() {
	return mobileNo;
}
public void setMobileNo(int mobileNo) {
	this.mobileNo = mobileNo;
}
@Override
public String toString() {
	return "CustomerValues [customerId=" + customerId + ", customername=" + customername + ", city=" + city
			+ ", mobileNo=" + mobileNo + "]";
}





}

