package practiceQue;
import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;
import java.util.*;


public class Question5 {
	public static void main(String args[])
	{
	 Scanner scanner=new Scanner(System.in);
     TreeSet<Customer>set=new TreeSet<Customer>();
    set.add(new Customer(1,"Lavanya",123456));
    set.add(new Customer(2,"Sanvi",123654));
    set.add(new Customer(3,"Akash",456123));
     Iterator<Customer>iterator=set.iterator();
     while(iterator.hasNext())
     {
         System.out.println(iterator.next());
     }
     System.out.println("Enter an integer from the user ");
     int ch=scanner.nextInt();
     System.out.println("Enter an String from user");
     String s=scanner.next();
     System.out.println("Enter another integer from user");
     int ch1=scanner.nextInt();
     Customer c=new Customer(ch,s,ch1);
     set.remove(c);
     System.out.println(set);
        
    
 }
}
