package practiceQue;

public class CustomerId {
public int customerId;

public CustomerId(int customerId) {
	super();
	this.customerId = customerId;
}

public int getCustomerId() {
	return customerId;
}

public void setCustomerId(int customerId) {
	this.customerId = customerId;
}

@Override
public String toString() {
	return "CustomerId [customerId=" + customerId + "]";
}

}
