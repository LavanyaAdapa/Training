package practiceQue;

public class Customer implements Comparable<Customer>{
public int customerid;
public String customername;
public long phoneNO;
public int phoneNumber;
public Customer()
{
	
}
public Customer(int customerid, String customername, long phoneNO) {
	super();
	this.customerid = customerid;
	this.customername = customername;
	this.phoneNO = phoneNO;
}
public int compareTo(Customer c)
{
    if(customerid >c.customerid)
    {
        return 1;
    }
    else if(customerid<c.customerid)
    {
        return -1;
    }
    else
        return 0;
       
}
       
static Customer customer=new Customer();
public int getCustomerid() {
	return customerid;
}
public void setCustomerid(int customerid) {
	this.customerid = customerid;
}
public String getCustomername() {
	return customername;
}
public void setCustomername(String customername) {
	this.customername = customername;
}
public long getPhoneNO() {
	return phoneNO;
}
public void setPhoneNO(long phoneNO) {
	this.phoneNO = phoneNO;
}
@Override
public String toString() {
	return "CustomerObjects [customerid=" + customerid + ", customername=" + customername + ", phoneNO="
			+ phoneNO + "]";
}

}
