package practiceQue;

import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class Question2 {

public static void main(String[] args)
{
Scanner scanner=new Scanner(System.in);
Set<Customer> treeset=new TreeSet<Customer>(new CompareName());
Set<Customer> treeset1=new TreeSet<Customer>();
System.out.println("how many details want to store");
int total=scanner.nextInt();
for(int i=1;i<=total;i++) {
    System.out.println("enter customer name");
    String name=scanner.next();
    System.out.println("enter customer mobile number");
    long phoneNO=scanner.nextLong();
    System.out.println("enter customer id");
    int id=scanner.nextInt();
    Customer customer=new Customer(id,name,phoneNO);
    treeset.add(customer);
    treeset1.add(customer);
}
System.out.println("By Name");
Iterator itr=treeset.iterator();
while(itr.hasNext()) {
    System.out.println(itr.next());
}

System.out.println("By Id");
Iterator itr1=treeset1.iterator();
while(itr1.hasNext()) {
    System.out.println(itr1.next());
}
}
}