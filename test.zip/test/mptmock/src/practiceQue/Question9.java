package practiceQue;
import java.util.Iterator;
import java.util.LinkedList;
public class Question9 {
	public static void main(String args[])
	{
	    LinkedList<Customer> linkedlist=new LinkedList<Customer>();
	    linkedlist.add(new Customer(1,"hyma",1234566));
	    linkedlist.add(new Customer(2,"anvi",5667891));
	    linkedlist.add(new Customer(3,"anitha",3456771));
	    linkedlist.add(new Customer(4,"jyothi",92345662));
	    
	    Customer c=new Customer(5,"Sammy",770270);
	    linkedlist.add(4,c);
	    linkedlist.remove(3);
	    Iterator iterator=linkedlist.iterator();
	    while(iterator.hasNext())
	    {
	        System.out.println(iterator.next());
	        
	    }
	    System.out.println(linkedlist);
	}
}
