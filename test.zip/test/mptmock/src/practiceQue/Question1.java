package practiceQue;


import java.util.TreeSet;

public class Question1 {
public static void main(String args[])
{
	TreeSet<Customer>customer=new TreeSet<Customer>();
	
	Customer customer3=new Customer(2,"Anusha",123438);
	Customer customer4=new Customer(4,"Sanjana",123465);
	Customer customer5=new Customer(3,"Vyshanvi",123444);	
	customer.add(customer3);
	customer.add(customer4);
	customer.add(customer5);
	for(Customer c:customer)
	{
		System.out.println(c.customerid+" "+c.customername+" "+c.phoneNumber);	
	}
		
}
}
