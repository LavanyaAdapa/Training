package practiceQue;


	import java.io.File;
	import java.io.FileInputStream;
	import java.io.FileNotFoundException;
	import java.io.FileOutputStream;
	import java.io.IOException;
	import java.io.ObjectInputStream;
	import java.io.ObjectOutputStream;

	public class Question15 { 

	
	public static void main(String args[])
	{
	    CustomerDetails1 c1 =new CustomerDetails1(1,"Sanjay",346777);
	    CustomerDetails1 c2 =new CustomerDetails1(2,"Ram",392345);
	    CustomerDetails1 c3 =new CustomerDetails1(3,"Rahul",123854);
	    CustomerDetails1 c4 =new CustomerDetails1(4,"Karthik",20101823);
	    
	    try
	    {
	        FileOutputStream f = new FileOutputStream(new File("source.txt"));
	        ObjectOutputStream o=new ObjectOutputStream(f);
	        
	        //writing object to file
	        o.writeObject(c1);
	        o.writeObject(c2);
	        o.writeObject(c3);
	        o.writeObject(c4);
	        o.close();
	        f.close();
	        
	        FileInputStream f1= new FileInputStream(new File("source.txt"));
	        ObjectInputStream o1=new ObjectInputStream(f1);
	        
	        //reading objects
	        CustomerDetails1 cd1=(CustomerDetails1) o1.readObject();
	        CustomerDetails1 cd2=(CustomerDetails1) o1.readObject();
	        CustomerDetails1 cd3=(CustomerDetails1) o1.readObject();
	        CustomerDetails1 cd4=(CustomerDetails1) o1.readObject();
	        
	        System.out.println(cd1.toString());
	        System.out.println(cd2.toString());
	        System.out.println(cd3.toString());
	        System.out.println(cd4.toString());
	        
	        o1.close();
	        f1.close();
	    }catch(FileNotFoundException e) {
	        System.out.println("File not found");
	    }catch(IOException e)
	    {
	        System.out.println("Error stream");
	    }catch(ClassNotFoundException e)
	    {
	        e.printStackTrace();
	    }    
	}
	}

