package capg1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import bean.Employee;

public class EmpDao {

	      public int addEmployee(Employee emp) {
	        int n = 0;
	        
	    try {
	        Connection conn=DBUtil.getConn();
	  String inserQuery ="Insert into employee1 values(?,?,?)";
	    
	    PreparedStatement pstmt=conn.prepareStatement(inserQuery);
	   
	   pstmt.setInt(1,emp.getEid());
	   pstmt.setString(2,emp.getEname());
	   pstmt.setDouble(3,emp.getSalary());
	   
	    n=pstmt.executeUpdate();
	   conn.close();
	   
	   } catch (SQLException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
	        
	    return n;
	        
	        
	    }
}
	    
	    
	    
	