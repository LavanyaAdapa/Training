package except;

public class SalaryException extends Exception {
	public SalaryException(String str)
	{
		System.out.println(str);
	}

}
