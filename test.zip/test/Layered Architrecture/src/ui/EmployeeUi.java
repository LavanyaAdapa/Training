package ui;
import java.util.Scanner;
import bean.Employe;
import dao.EmployeeDao;
import service.EmployeeService;
import except.SalaryException;
public class EmployeeUi {
public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	System.out.println("enter employee id:");
	int eId=sc.nextInt();
	System.out.println("enter employee name:");
	String eName=sc.next();
	System.out.println("enter employee salary:");
	double eSalary=sc.nextDouble();
	Employe e=new Employe(eId,eName, eSalary);
	EmployeeService es=new EmployeeService();
	EmployeeDao ed=new EmployeeDao();
	es.calculateInsentive(e);
	ed.storeEmployeeDetails(e);
	ed.getEmployeeDetails(e);
	try
	{
		if(eSalary<5000)
		{
		throw new SalaryException("Salary should be greater than 5000");	
		}
		else
		{
			System.out.println("Salary:"+eSalary);
		}
	}
	catch(SalaryException e1)
	{
		e1.printStackTrace();
	}
	sc.close();
}
}
