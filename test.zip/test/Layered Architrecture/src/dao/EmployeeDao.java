package dao;
	import java.util.Scanner;
	import bean.Employe;
	public class EmployeeDao implements EmployeeDaoIntf{
		public void storeEmployeeDetails(Employe e)
		{
			Employe emp[]=new Employe[1];
			emp[0]=e;
		}
		public Employe getEmployeeDetails(Employe e1)
		{
			Scanner scan=new Scanner(System.in);
			System.out.println("enter employee id to fetch");
			int id=scan.nextInt();
			int id1=e1.getEmpId();
			for(int i=0;i<=1;i++)
			{
				if(id==e1.getEmpId())
					System.out.println(e1);
			}
			return e1;
		}

	}

