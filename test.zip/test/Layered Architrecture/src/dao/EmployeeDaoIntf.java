package dao;
import bean.Employe;
public interface EmployeeDaoIntf {
public void storeEmployeeDetails(Employe e);
public Employe getEmployeeDetails(Employe e);
}
