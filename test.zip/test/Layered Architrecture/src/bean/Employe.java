package bean;

public class Employe {
int empId;
String empName;
double Salary;
public Employe(int empId,String empName,double Salary)
{
	this.empId=empId;
	this.empName=empName;
	this.Salary=Salary;
}
public int getEmpId() {
	return empId;
}
public void setEmpId(int empid) {
	this.empId = empid;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public double getSalary() {
	return Salary;
}
public void setSalary(double salary) {
	this.Salary = salary;
}
}
