package service;
import bean.Employe;
public interface EmployeeServiceInterface {
public void calculateInsentive(Employe e);
}
