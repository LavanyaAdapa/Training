package service;
import bean.Employe;
public class EmployeeService implements EmployeeServiceInterface {
public void calculateInsentive(Employe e)
{
	double d=e.getSalary()+5000;
	e.setSalary(d);
}
}
