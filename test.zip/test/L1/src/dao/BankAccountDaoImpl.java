package dao;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import bean.Customer;
import bean.Transaction;

public interface BankAccountDaoImpl {
	static List<Transaction> printTransaction=new ArrayList<>();
	Map<Integer,Customer> customerList=new HashMap<>();
	public int createAccount(Customer customer);
	public double showBalance(int accountNo);
	List<Transaction> deposit(int accountNo,double amount);
	List<Transaction> withdraw(int accountNo,double amount);
	List<Transaction> fundTransfer(int sourceAccount,int destinationAccount,double amount);
	List<Transaction> PrintTransaction(int accountNo);
}



