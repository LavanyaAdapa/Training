package bean;
public class Transaction {
	private int account_no;
	private int transaction_Id;
	private String transaction_type;
	private String transaction_Date;
	private double amount;
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Transaction(int account_no, int transaction_Id, String transaction_type, String transaction_Date,
			double amount) {
		super();
		this.transaction_Id = transaction_Id;
		this.transaction_type = transaction_type;
		this.transaction_Date = transaction_Date;
		this.account_no = account_no;
		this.amount = amount;
	}
	public int getTransaction_Id() {
		return transaction_Id;
	}
	public void setTransaction_Id(int transaction_Id) {
		this.transaction_Id = transaction_Id;
	}
	public String getTransaction_type() {
		return transaction_type;
	}
	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}
	public String getTransaction_Date() {
		return transaction_Date;
	}
	public void setTransaction_Date(String transaction_Date) {
		this.transaction_Date = transaction_Date;
	}
	public int getAccount_no() {
		return account_no;
	}
	public void setAccount_no(int account_no) {
		this.account_no = account_no;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "account_no=" + account_no + ", transaction_Id=" + transaction_Id + ", transaction_type="
				+ transaction_type + ", transaction_Date=" + transaction_Date + ", amount=" + amount;
	}
	
	
	
}

