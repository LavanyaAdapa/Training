package service1;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import bean.Customer;
import bean.Transaction;
import dao.BankAccountDao;
import dao.BankAccountDaoImpl;
import exception.BankException;

public class BankAccountService implements BankAccountServiceImpl {
	BankAccountDao accountDao=new BankAccountDao();
	@Override
	public int createAccount(Customer customer) throws BankException{
		return accountDao.createAccount(customer);
	}

	@Override
	public double showBalance(int accountNo) throws BankException{
		return accountDao.showBalance(accountNo);
	}

	@Override
	public List<Transaction> deposit(int accountNo,double amount) throws BankException{
		
		return accountDao.deposit(accountNo,amount);
	}

	@Override
	public List<Transaction> withdraw(int accountNo,double amount) throws BankException{
		
		return accountDao.withdraw(accountNo,amount);
	}

	@Override
	public List<Transaction> fundTransfer(int sourceAccount,int destinationAccount,double amount) throws BankException{
		
		return accountDao.fundTransfer(sourceAccount, destinationAccount, amount);
	}

	@Override
	public List<Transaction> PrintTransaction(int accountNo) throws BankException{
		
		return accountDao.PrintTransaction(accountNo);
	}

	@Override
	public boolean validateName(String name) throws BankException{
		Pattern namePattern=Pattern.compile("[A-Z]{1}[a-z]{4,}");
		Matcher matcher=namePattern.matcher(name);
		if(matcher.matches())
			return true;
		else
			throw new BankException("Name should start with captial letter");
	}

	@Override
	public boolean validateMail(String mail) throws BankException {
		int length=mail.length();
		Pattern mailPattern=Pattern.compile("[@gamil.com]{length-11,length-1}");
		Matcher matcher=mailPattern.matcher(mail);
		if(matcher.matches())
			return true;
		else
			throw new BankException("Mail should end with @gmail.com");
	}

	@Override
	public boolean validateMobile(String mobile) throws BankException {
		Pattern mobilePattern=Pattern.compile("[7,8,9]{1}[0-9]{9}");
		Matcher matcher=mobilePattern.matcher(mobile);
		if(matcher.matches())
			return true;
		else
			return false;
	}

	@Override
	public boolean validateAddress(String address) throws BankException {
		Pattern mobilePattern=Pattern.compile("[A-Za-z]{10,}");
		Matcher matcher=mobilePattern.matcher(address);
		if(matcher.matches())
			return true;
		else
		return false;
	}

}


