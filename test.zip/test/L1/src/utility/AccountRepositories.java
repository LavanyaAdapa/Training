package utility;

import java.util.HashMap;
import java.util.Map;

import bean.Customer;

public class AccountRepositories {
static HashMap<Integer, Customer> customerList=new HashMap<>();
	
	static {
		customerList.put(845,new Customer(845,"ramya","rvagdevi699@gmail.com","8096368415","kakinada",50000));
		customerList.put(563,new Customer(563,"anirudh","salagrama94anirudh@gmail.com","9951054145","hyderabad",450000));
	}

	public static HashMap<Integer, Customer> getCustomerList() {
		return customerList;
	}

	public static void setCustomerList(HashMap<Integer, Customer> customerList) {
		AccountRepositories.customerList = customerList;
	}

	
	
	
}



