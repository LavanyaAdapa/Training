import java.sql.*;
import java.util.Scanner;
public class PreparedStatementUpdateDemo {
public static void main(String args[])
{
	Connection con;
	PreparedStatement pst;
	Scanner scanner=new Scanner(System.in);
	System.out.println("Enter customer_name:");
	String cust_name=scanner.next();
	System.out.println("Enter customer_id:");
	int cust_id=scanner.nextInt();
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
		 con=DriverManager.getConnection(
			"jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg532","training532");
		pst=con.prepareStatement("update customers_new set customer_name=? where customer_id=?");
		pst.setString(1,cust_name);
		pst.setInt(2,cust_id);
		pst.executeUpdate();
		System.out.println("Row updated");
	}catch(Exception e)
	{
	System.out.println(e);	
	}
}
}
