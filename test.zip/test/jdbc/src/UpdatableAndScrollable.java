import java.sql.*;
public class UpdatableAndScrollable {
public static void main(String args[])
{
	Connection con;
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con=DriverManager.getConnection(
				"jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg532","training532");
		Statement statement=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
	ResultSet results=statement.executeQuery("Select customer_id,customer_name from customers_new");
	int concurrency=results.getConcurrency();
	System.out.println(concurrency);
	System.out.println(ResultSet.CONCUR_UPDATABLE);
	if(concurrency==ResultSet.CONCUR_UPDATABLE)
	{
	results.absolute(2);
	results.updateString(2,"sammy");
	results.updateRow();
	}
	else
	{
		System.out.println("ResultSet is not an updatable result set.");
	}
	}catch(Exception e)
	{
		System.out.println(e);
	}
}
}
