package jdbclabex;
import java.sql.*;
import java.util.Scanner;
public class AuthorModule {
static Scanner scanner=new Scanner(System.in);
static String firstName,middleName,lastName,phoneNo;
static int authorid,choice,update;
static String column_name=null,
newValue=null;

public static void main(String args[])throws ClassNotFoundException,SQLException
{
	int close=0;
	PreparedStatement psmt=null;
	ResultSet rs=null;
	//First Step
	//loading driver class
	Class.forName("oracle.jdbc.driver.OracleDriver");
	//second step
	//create connection
	Connection con=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg532","training532");
	while(close==0)
	{
		System.out.println("1.Create Account");
		System.out.println("2.Show Info");
		System.out.println("3.Update Info");
		System.out.println("4.Delete Info");
		System.out.println("5.Books Info");
		System.out.println("6.Update Book Price");
		System.out.println("Enter your choice:");
		int input=scanner.nextInt();
		switch(input)
		{
		case 1:
			String Q_insert="insert into Author(authorid,firstName,middleName,lastName,phoneNo,booksisbn)values(?,?,?,?,?,isbn_seq.nextval)";
			System.out.println("Enter your Author ID:");
			authorid=scanner.nextInt();
			System.out.println("Enter your First Name:");
			firstName=scanner.next();
			System.out.println("Enter your Middle Name:");
			middleName=scanner.next();
			System.out.println("Enter your Last Name:");
			lastName=scanner.next();
			System.out.println("Enter your Phone No:");
			phoneNo=scanner.next();
			
			psmt=con.prepareStatement(Q_insert);//create a statement
			psmt.setInt(1,authorid);//set input parameter1
			psmt.setString(2,firstName);
			psmt.setString(3,middleName);
			psmt.setString(4,lastName);
			psmt.setString(5,phoneNo);
			//psmt.setString(6.isbn_seq);
			int i=psmt.executeUpdate();//execute insert statement
			if(i==1)
			{
				System.out.println("Account created successfully ");
			}
			else
			{
				System.out.println("Account creation failed ");
			}
			break;
		case 2:
			String Q_select ="select authorid,firstName,middleName,lastName,phoneNo from Author where authorid=?";
			psmt=con.prepareStatement(Q_select);//create statement
			System.out.println("Enter your Author ID:");
			authorid=scanner.nextInt();
			psmt.setInt(1,authorid);//set input parameter
			rs=psmt.executeQuery();
			
			//extract data from resultset
			while(rs.next())
			{
				authorid=rs.getInt(1);
				firstName=rs.getString(2);
				middleName=rs.getString(3);
				lastName=rs.getString(4);
				phoneNo=rs.getString(5);
				System.out.println("Your ID:"+authorid);
				System.out.println("Your Name:"+firstName);
				System.out.println("Your Middle"+middleName);
				System.out.println("Your lastName"+lastName);
				System.out.println("Your PhoneNo:"+phoneNo+"\n");
				
			}
			break;
		case 3:
			System.out.println("Enter your Author ID");
			authorid=scanner.nextInt();
			System.out.println("What you want to update?\n1.First Name\n2.Middle Name\n3.Last name\n4.PhoneNo");
			choice=scanner.nextInt();
			if(choice==1)
			{
				column_name="firstName";
			}else if(choice==2)
			{
				column_name="middleName";
			}else if(choice==3)
			{
				column_name="lastName";
			}else if(choice==4)
			{
				column_name="phoneNo";
			}else {
				System.out.println("Enter a valid choice");
			}
			System.out.println("Enter new value:");
			newValue=scanner.next();
			String Q_update_2="update Author set"+column_name+"=?where authorid=?";
			psmt=con.prepareStatement(Q_update_2);
			psmt.setString(1,newValue);
			psmt.setInt(2,authorid);
			update=psmt.executeUpdate();
			if(update==1)
			{
				System.out.println("Info updated");
			}else {
				System.out.println("Sorry something went wrong");
			}
			break;
		case 4:
			System.out.println("Enter your Author ID:");
			authorid=scanner.nextInt();
			System.out.println("What you want to delete?\n1.First Name\n2.Middle Name\n3.Last name\n4.PhoneNo");
			choice=scanner.nextInt();
			if(choice==1)
			{
				column_name="firstName";
			}else if(choice==2)
			{
				column_name="middleName";
			}else if(choice==3)
			{
				column_name="lastName";
			}else if(choice==4)
			{
				column_name="phoneNo";
			}else {
				System.out.println("Enter a valid choice");
			}
			String Q_delete="update Author set"+column_name+"=null where authorid=?";
			psmt=con.prepareStatement(Q_delete);
			psmt.setInt(1,authorid);
			update=psmt.executeUpdate();
			if(update==1)
			{
				System.out.println("Info Updated");
			}else
			{
				System.out.println("Sorry,Something went wrong");
			}
			break;
		case 5:
			System.out.println("Enter your Author ID:");
			authorid=scanner.nextInt();
			String showBookTitle="select a.authorid,b.title from Author a,Book b where a.authorid=b.authorid";
			psmt=con.prepareStatement(showBookTitle);
			ResultSet resultSet=psmt.executeQuery();
			while(resultSet.next())
			{
				int i1=1;
				int id=resultSet.getInt(1);
				if(id==authorid)
				{
					String title=resultSet.getString(2);
					System.out.println(i1+""+title);
					i1++;
				}
			}
			break;
		case 6:
			System.out.println("Enter Author Name:");
			String authorName=scanner.next();
			System.out.println("Enter Author ID:");
	        authorid=scanner.nextInt();
	        String showBooks="select a.authorid,b.title from Author a,Book b where a.authorid=b.authorid";
	        psmt=con.prepareStatement(showBooks);
	        ResultSet resultSet1=psmt.executeQuery();
	        while(resultSet1.next())
	        {
	        	int id=resultSet1.getInt(1);
	        	if(id==authorid)
	        	{
	        		String title=resultSet1.getString(2);
	        		System.out.println(""+title);
	        		System.out.println("Enter Book Name");
	        		String bookName=scanner.next();
	        		System.out.println("Enter Price:");
	        		int bookPrice=scanner.nextInt();
	        		String updatePrice="update Book set Price=? where title=?";
	        		psmt.setInt(1,bookPrice);
	        		psmt.setString(2,bookName);
	        		update=psmt.executeUpdate();
	        		if(update==1)
	        		{
	        			System.out.println("Price Updated");
	        		}else
	        		{
	        			System.out.println("Operation Failed");
	        		}
	        	}
	        }
		break;
		default :
			System.out.println("Please enter valid choice:");
			break;
			
		}

	}
}
}
