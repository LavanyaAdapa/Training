package lab;
import java.sql.*;
public class OracleServer1 {
	
    public static void main(String args[])
   {
       try {
           Class.forName("oracle.jdbc.driver.OracleDriver");
        
           Connection con=DriverManager.getConnection(
                   "jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg532","training532");
                
           Statement stmt=con.createStatement();
           /*stmt.execute("update customers_new50 set customer_name='swapna' where customer_id=20");
           System.out.println("row updated");*/
 stmt.execute("Alter table cust_table add constraint Custid_prim PRIMARY KEY (customerid)");
           System.out.println(" ALTERED");
        
           /*ResultSet rs=stmt.executeQuery("select * from cust_table");
           System.out.println(rs);
           while(rs.next())
           System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3));    */
           con.close();
       }catch(Exception e) {System.out.println(e);}
   }

}
