package lab;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class OracleServer {
	public static void main(String args[])
    {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            
            Connection con=DriverManager.getConnection(
                    "jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg532","training532");
                    
            Statement stmt=con.createStatement();
           
            
            stmt.execute("insert into cust_table values(1002,'John','#114 Chicago','#114 Chicago','M',45,439525)");
            System.out.println("row inserted");
            
          
            con.close();
        }catch(Exception e) {System.out.println(e);}
    }
}
