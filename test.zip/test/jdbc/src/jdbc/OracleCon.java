package jdbc;
import java.sql.*;
public class OracleCon {
public static void main(String args[])
{
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
		Connection con=DriverManager.getConnection(
			"jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg532","training532");
		
		Statement stmt=con.createStatement();
		
		/*stmt.execute("update customers_new set customer_name='sam' where customer_id=3");
		System.out.println("row updated");
		stmt.execute("insert into customers_new values(7,'Sahasra','Simonsroad',7702708333,'Hyderabada'"));
		System.out.println("Row Inserted");*/
		  ResultSet rs=stmt.executeQuery("select * from customers_new");
	        System.out.println(rs);
	        while(rs.next())
	        System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3));   
	        con.close();
		}catch(Exception e) {System.out.println(e);}
	}
}

