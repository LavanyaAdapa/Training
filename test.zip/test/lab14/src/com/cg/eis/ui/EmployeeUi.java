package com.cg.eis.ui;
import java.util.Scanner;
import com.cg.eis.bean.Employee;
public class EmployeeUi {
public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Employee Details :");
	System.out.println("Enter Employee Id:");
	int id=sc.nextInt();
	System.out.println("Enter Name:");
	String name=sc.next();
	System.out.println("Enter Employee Salary :");
	long salary=sc.nextLong();
	System.out.println("Enter Employee Designation:");
	String design=sc.next();
	System.out.println("Enter Employee InsuranceScheme:");
	String insuranceScheme=sc.next();
}
}
