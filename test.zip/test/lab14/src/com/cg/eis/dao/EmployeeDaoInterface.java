package com.cg.eis.dao;

import com.cg.eis.bean.Employee;

public interface EmployeeDaoInterface {
	public void storeEmployee(Employee e);
	public void retriveEmployee(Employee e);
}
