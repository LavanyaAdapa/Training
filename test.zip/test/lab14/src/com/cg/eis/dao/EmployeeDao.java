package com.cg.eis.dao;
import com.cg.eis.bean.Employee;
import com.cg.eis.ui.EmployeeUi;
public class EmployeeDao implements EmployeeDaoInterface{
public void storeEmployee(Employee e)
{
	
}
public void retriveEmployee(Employee e)
{
	
}
}
