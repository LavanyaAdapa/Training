package service;

public class MobileService {

}
