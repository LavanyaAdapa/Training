package dao;

public interface MobileDaoInterface {

}
