package dao;
import bean.Mobile;
import java.util.Scanner;
public class MobileDao {
public void storeCustomerDetails(Mobile m)
{
	Mobile m1[]=new Mobile[2];
}
public Mobile getDetails(Mobile m1)
{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Mobile Number:");
	int number=sc.nextInt();
	System.out.println("Enter simType:");
	String simType=sc.next();
	System.out.println("Enter state:");
	String state=sc.next();
}
}
