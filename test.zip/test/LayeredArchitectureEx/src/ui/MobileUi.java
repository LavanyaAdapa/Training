package ui;
import bean.Mobile;
import bean.Customer;
import java.util.Scanner;
public class MobileUi {
public static void main(String args[])
{
	  
	Scanner sc=new Scanner(System.in);
	int i=sc.nextInt();
	switch(i)
	{
	case 1:
		Mobile m=new Mobile(123456,"Andhra Pradesh","National");
		Mobile m2=new Mobile(987654,"Andhra Pradesh","InterNational");
		System.out.println(m);
		System.out.println(m2);
		break;
	case 2:
		Customer c=new Customer(12,"ahana");
		Customer c2=new Customer(13,"vihana");
		System.out.println(c);
		System.out.println(c2);
		break;
	case 3:
		System.out.println("Exit");
		break;
	}
	
}
}
