package bean;

public class Mobile {
private int number;
private String simType;
private String state;
public Mobile(int number,String simTyope,String State)
{
	this.number=number;
	this.simType=simType;
	this.state=state;
}

public int getNumber() {
	return number;
}
public void setNumber(int number) {
	this.number = number;
}
public String getSimType() {
	return simType;
}
public void setSimType(String simType) {
	this.simType = simType;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
@Override
public String toString() {
	return "Mobile [ number=" + number + ", simType=" + simType	+ ", state=" + state + "]";
}

}
