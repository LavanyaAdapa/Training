package bean;

public class Customer {
	static int customerId;
	private String customerName;
	public Customer(int customerId,String customerName)
	{
		this.customerId=customerId;
		this.customerName=customerName;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getcustomerName() {
		return customerName;
	}
	public void setcustomerName(String name) {
		this.customerName = name;
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + "]";
	}
	
}
