package abc;

public class Base {

	
}
class Sub extends Base
{
	
}