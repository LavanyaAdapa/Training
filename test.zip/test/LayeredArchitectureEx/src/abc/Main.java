package abc;

public class Main {
static void input(Base b)
{
	
}
public static void main (String args[])
{
	Base b1=new Base();
	Sub s1=new Sub();
	input(b1);
	input(s1);
}
}
