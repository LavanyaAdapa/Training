package Lab3;

public class secondSmallest {
public static int getSecondSmallest(int x[],int n)
 {
	 int temp;
	 for(int i=0;i<n;i++)
	 {
		 for(int j=i+1;j<n;j++)
		 {
			 if(x[i]>x[j])
			 {
			 temp=x[i];
			 x[i]=x[j];
			 x[j]=temp;
		 }
	 }
	 }
 
return x[1];
}
 public static void main(String args[])
 {
	 int x[]={2,5,3,8,6,0,9};
	 System.out.println(getSecondSmallest(x,7));
 }
}
