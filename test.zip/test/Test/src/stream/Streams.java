package stream;

import java.util.*;

import java.util.stream.Collectors;


public class Streams {
public static void main(String args[])
{ 
	
List<String>list=Arrays.asList("abc","def","ghi");


}
}
