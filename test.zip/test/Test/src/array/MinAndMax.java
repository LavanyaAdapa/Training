package array;
import java.util.Scanner;
public class MinAndMax {

	public  int getMaxValue(int[]number)
	{
		 int maxValue=number[0];
		for(int i=1;i<number.length;i++)
		{
			if(number[i]>maxValue) {
				maxValue=number[i];
			}
		}
		return maxValue;
	}
	public int getMinValue(int[]number)
	{
		int minValue=number[0];
		for(int i=1;i<number.length;i++)
		{
			if
			(number[i]<minValue)
			{
				minValue=number[i];
			}
		}
		return minValue;	
	
}

public static void main(String args[])
{
	int[]number= {120,55,60,45,100};
	MinAndMax m=new MinAndMax();
	System.out.println("Maximum value :"+m.getMaxValue(number));
	System.out.println("Minimum value :"+m.getMinValue(number));
}
}