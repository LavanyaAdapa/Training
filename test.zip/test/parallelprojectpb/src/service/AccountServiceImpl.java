package service;

import java.util.Collection;

import bean.Account;
import exception.AccountNotFoundException;

public interface AccountServiceImpl {
	public Account createAccount(Account account);
    public void deposit(int accountNo, double amount) throws AccountNotFoundException;
    public void withdraw(int accountNo, double amount) throws AccountNotFoundException;
    //public void fundsTransfer(Account fromAccount, Account toAcctount, double amount) throws AccountNotFoundException;
    public Account getBalance(int accountNo) throws AccountNotFoundException;
    public Collection<Account> getTransactions();
}
