package dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import bean.Account;
import exception.AccountNotFoundException;
import exception.InSufficientBalanceException;

public class AccountDAO implements AccountDAOImpl {
Map<Integer, Account> map_Account;
    
    public AccountDAO(int size) {
        map_Account = new HashMap<Integer, Account>(size);
    }

 

    @Override
    public int createAccount(Account account) {
        map_Account.put(account.getAccountNo(), account);
        return account.getAccountNo();
    }

 

    @Override
    public void deposit(int accountNo, double amount) throws AccountNotFoundException {
        Account account = map_Account.get(accountNo);
        if(account == null) throw new AccountNotFoundException(accountNo+" does not exists...");
        double currentBalance = account.getCurrentBalance();
        currentBalance += amount;
        account.setCurrentBalance(currentBalance);
        //map_Account.put(account.getAccountNo(), account);
    }

 

    @Override
    public void withdraw(int accountNo, double amount)throws AccountNotFoundException, InSufficientBalanceException {
        Account account = map_Account.get(accountNo);
        if(account == null) throw new AccountNotFoundException(accountNo+" does not exists...");
        double currentBalance = account.getCurrentBalance();
        if(currentBalance <= amount) throw new InSufficientBalanceException();
        currentBalance -= amount;
        account.setCurrentBalance(currentBalance);
    }
    
    @Override
    public void fundsTransfer(int accountNoFrom, int accountNoTo, double amount)throws AccountNotFoundException, InSufficientBalanceException {
        Account accountFrom = map_Account.get(accountNoFrom);
        if(accountFrom == null) throw new AccountNotFoundException(accountNoFrom+" does not exists...");
        
        Account accountTo = map_Account.get(accountNoTo);
        if(accountTo == null) throw new AccountNotFoundException(accountNoTo+" does not exists...");

 

        System.out.println("Account From:"+ accountNoFrom);
        System.out.println("Account To  :"+ accountNoTo);
        
        double accountFromBalance =  accountFrom.getCurrentBalance();
        if(accountFromBalance <= amount) throw new InSufficientBalanceException();
        
        accountFromBalance -= amount;
        accountFrom.setCurrentBalance(accountFromBalance);
        
        double accountToBalance = accountTo.getCurrentBalance();
        accountToBalance += amount;
        
        accountTo.setCurrentBalance(accountToBalance);
        
        System.out.println("Account From:"+ accountNoFrom);
        System.out.println("Account To  :"+ accountNoTo);

 

    }
    
    @Override
    public double getBalance(int accountNo) throws AccountNotFoundException {
        Account account = map_Account.get(accountNo);
        if(account == null) throw new AccountNotFoundException(accountNo+" does not exists...");
        return map_Account.get(accountNo).getCurrentBalance();
    }

 

    @Override
    public Collection<Account> getTransactions() {
        return map_Account.values();
    }
}
