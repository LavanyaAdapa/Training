package dao;

import java.util.HashMap;
import bean.TableBooking;
import bean.Customer;
import bean.TableType;
public class TableData implements TableDataIntf {
public static HashMap<TableBooking,Customer>hm=new HashMap<TableBooking,Customer>();

public void storeData(TableBooking td)
{
	Customer c=new Customer(43,"Anvi",123456789);
    Customer c1=new Customer(44,"Rani",789456123);
    Customer c2=new Customer(45,"Yamuna",89635785);
    Customer c3=new Customer(9949481,"Pavani",78945612);
    TableBooking tb1=new TableBooking(1,TableType.TWO_SEATER);
    TableBooking tb2=new TableBooking(2,TableType.TWO_SEATER);
    TableBooking tb3=new TableBooking(3,TableType.TWO_SEATER);
    TableBooking tb4=new TableBooking(4,TableType.TWO_SEATER);
    hm.put(tb1,c);
    hm.put(tb2,c1);
    hm.put(tb3,c2);
    hm.put(tb4,c3);
}
public HashMap<TableBooking, Customer> hm()
{
    return hm;
    
}



}
