package dao;
import bean.TableBooking;
public interface TableDataIntf {
public void storeData(TableBooking td);

}
