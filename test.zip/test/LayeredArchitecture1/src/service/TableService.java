package service;
import java.util.Scanner;

import bean.Customer;
import bean.TableBooking;
public class TableService implements TableServiceIntf {
	TableService ts;
	TableBooking tb=new TableBooking();

	Scanner sc=new Scanner(System.in);
	
	
	
	public void reservation(TableBooking tb) {
		
		
	}
	
	public void addTable(TableBooking tb) {
		
		
	}
	public void customerDetails(Customer c)
	{
	   System.out.println("Enter customer name:");
	   String name=sc.next();
	}

	public boolean isAvailability(TableBooking tb) {
		
		return true;
	}
}
