package service;
import bean.Customer;
import bean.TableBooking;
public interface TableServiceIntf {
public void reservation(TableBooking tb);
public void addTable(TableBooking tb);
public void customerDetails(Customer c);
public boolean isAvailability(TableBooking tb);
}
