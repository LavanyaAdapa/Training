package ui;
import service.TableService;
import bean.TableBooking;
import dao.TableData;

import java.util.Scanner;

public class MainUi {
public static void main(String args[])
{
	TableService ts = new TableService();
	TableBooking tb=new TableBooking();
	for(;;)
	{
		
	   

		Scanner sc=new Scanner(System.in);
		System.out.println("1.Book a table:");
		System.out.println("2.Check Availability");
		System.out.println("3.Add new table to restaurant:");
		System.out.println("4.Display customer Deatils based on customerId:");
		System.out.println("5.Exit");
		System.out.println("Enter your choice:");
		int ch=sc.nextInt();
		
		
		
		
		switch(ch)
        {
        case 1:
            ts.reservation(tb);
            break;
        case 2:
            ts.addTable(tb);
            break;
        case 3:
            ts.customerDetails(null);
            break;
        case 4:
        	ts.isAvailability(tb);
        	break;
        case 5:
            System.out.println("Exit");
            break;
    }
		 }           
	}

}
