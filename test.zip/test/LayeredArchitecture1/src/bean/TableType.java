package bean;

public enum TableType {
        TWO_SEATER,FOUR_SEATER,SIX_SEATER,EIGHT_SEATER;
}
