package bean;

public class TableBooking {
private int tableId;
TableType tabletype;
public  TableBooking()
{	
}
public TableBooking(int tableId,TableType tabletype)
{
	this.tableId=tableId;
	this.tabletype=tabletype;
}
public int getTableId() {
	return tableId;
}
public void setTableId(int tableId) {
	this.tableId = tableId;
}
public TableType getTabletype() {
	return tabletype;
}
public void setTabletype(TableType tabletype) {
	this.tabletype = tabletype;
}
@Override
public String toString() {
	return "TableBooking [tableId=" + tableId + ", tabletype=" + tabletype + "]";
}

}
