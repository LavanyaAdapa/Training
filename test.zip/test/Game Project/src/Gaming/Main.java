package Gaming;
import java.util.Scanner;
public class Main {
public static void main(String args[])
{
	String ans;
	while(true)
	{
	Scanner in=new Scanner(System.in);
	System.out.println("MENU\n");
	System.out.println("GAME MENU\n");
	System.out.println("START\n");
	System.out.println("DESCRIPTION\n");
	System.out.println("EXIT\n");
	int choice=in.nextInt();
	switch(choice)
	{
	case 1:gameStart();
		break;
	case 2:gameDescription();
		break;
	case 3:gameExit();
	System.out.println("Do you want to continue Yes/No");
	ans=in.next();
	if(ans.equals("No"))
		System.exit(choice);
		break;
	}		
}
}
private static void gameExit()
{
	System.out.println("exit");
}
private static void gameDescription()
{
	System.out.println("Description");
}
private static void gameStart()
{
	System.out.println("Started");
}
}
