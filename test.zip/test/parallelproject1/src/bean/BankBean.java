package bean;

public class BankBean {
private long AccNo;
private float balance,depAmount,withdrawlAmount,transferAmount;
private String name;
private long mobileNo, accNo;
public BankBean(long AccNo,String name,long mobileNo,float balance,float depAmount,float withdrawlAmount,float transferAmount)
{
	this.AccNo=AccNo;
	this.name=name;
	this.mobileNo=mobileNo;
	this.balance=balance;
	this.depAmount=depAmount;
	this.withdrawlAmount=withdrawlAmount;
	this.transferAmount=transferAmount;
}

public long getAccNo() {
	return AccNo;
}
public void setAccNo(long accNo) {
	AccNo = accNo;
}
public float getBalance() {
	return balance;
}
public void setBalance(float balance) {
	this.balance = balance;
}
public float getDepAmount() {
	return depAmount;
}
public void setDepAmount(float depAmount) {
	this.depAmount = depAmount;
}
public float getWithdrawlAmount() {
	return withdrawlAmount;
}
public void setWithdrawlAmount(float withdrawlAmount) {
	this.withdrawlAmount = withdrawlAmount;
}
public float getTransferAmount() {
	return transferAmount;
}
public void setTransferAmount(float transferAmount) {
	this.transferAmount = transferAmount;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public long getMobileNo() {
	return mobileNo;
}
public void setMobileNo(long mobileNo) {
	this.mobileNo = mobileNo;
}
@Override
public String toString() {
	return "BankBean [AccNo=" + AccNo + ", balance=" + balance + ", depAmount=" + depAmount + ", withdrawlAmount="
			+ withdrawlAmount + ", transferAmount=" + transferAmount + ", name=" + name + ", mobileNo=" + mobileNo
			+ ", accNo=" + accNo + "]";

}
}
