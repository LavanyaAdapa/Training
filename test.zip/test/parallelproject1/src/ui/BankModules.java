package ui;
import java.util.*;
import bean.BankBean;
public class BankModules {
	Scanner sc=new Scanner(System.in);
	
public void createAccount()
{
	System.out.println("Enter Name:");
	String name=sc.next();
	System.out.println("Enter Mobile Number");
	long MobileNo=sc.nextLong();
	
}
}
