package ui;
import bean.BankBean;
import java.util.*;
import ui.BankModules;
public class BankUi {
public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	BankModules bm=new BankModules();
	int ch;
		System.out.println("1.Create Account\n 2.Show Balance\n 3.Deposit\n 4.WithDraw\n 5.FundTransfer\n 6.PrintTransactions\n 7.Exit");
		do{
		System.out.println("Enter your choice :");
		 ch=sc.nextInt();
	
		 switch(ch)
		 {
			 case 1:
				 bm. createAccount();
				  break;
			/* case 2:
				 showBalance();
				 break;
			 case 3:
				 Deposit();
				 break;
			 case 4:
				 WithDraw();
				 break;
			 case 5:
				 FundTransfer();
				 break;
			 case 6:
				 printTransactions();
				 break;
			 case 7:
				 Exit();
				 break;*/
				 
		 }
	}while(ch!=7);
}
}
