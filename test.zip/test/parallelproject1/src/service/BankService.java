package service;
import bean.BankBean;
import dao.BankDao;
import ui.BankUi;
public class BankService {
	BankDao bdObj=new BankDao();
public void bankAccountCreate(BankBean bobj){
	bdObj.addCustomer(bobj);
}
}
