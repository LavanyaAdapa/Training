package dao;
import bean.BankBean;
import java.util.HashMap;
public class BankDao {
BankBean bobj;
HashMap<Long,BankBean> hm=new HashMap<Long,BankBean>();
public void addCustomer(BankBean bobj)
{
	this.bobj=bobj;
	hm.put(bobj.getAccNo(),bobj);
}
}
