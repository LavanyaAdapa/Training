package concurrent;
import java.util.function.*;
public class ConsumerExample {
public static void main(String args[])
{
	IntConsumer ic=(num)->System.out.println(num);
	ic.accept(76);
}
}
