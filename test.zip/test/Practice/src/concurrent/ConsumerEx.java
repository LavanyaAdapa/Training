package concurrent;
import java.util.function.*;
public class ConsumerEx {
public static void main(String args[])
{
	Consumer<String> s=(msg)->System.out.println("Welcome");
	s.accept("Welcome");
}
}
