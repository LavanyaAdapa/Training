package concurrent;
import java.util.function.*;
public class Lambda {
public static void main(String args[])
{
	BooleanSupplier bs=()->true; 
	System.out.println(bs.getAsBoolean());
}
}
