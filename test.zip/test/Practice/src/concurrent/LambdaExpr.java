package concurrent;
import java.util.function.*;
public class LambdaExpr {
public static void main(String args[])
{
Supplier<String> s=()->"Hello World";
System.out.println(s.get());
}
}
