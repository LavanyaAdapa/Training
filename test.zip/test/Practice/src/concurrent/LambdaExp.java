package concurrent;
interface Sum{
	void abstractfun(int n);
}
public class LambdaExp {
public static void main(String args[])
{
	Sum sobj=(int n)->System.out.println(n+10);
	sobj.abstractfun(2);
}
}
