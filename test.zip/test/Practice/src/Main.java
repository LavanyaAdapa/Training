import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;
public class Main {
public static void main(String args[])
{
	List<Integer>l=new ArrayList<Integer>();
	
	l.add(15);
	l.add(20);
	l.add(25);
	l.add(15);
	Stream<Integer>s=l.stream();
	//Stream<Integer>st=s.filter(i->i%2==0);
	//st.forEach(System.out::println);
	//st.forEach(i->System.out.println(i)); 
	//List st1=l.stream().map(i->i+5).collect(Collectors.toList());
	//System.out.println(st1);
	//List obj=st.collect(Collectors.toList());
	//long c=st1.stream().count();
	//System.out.println(c);
	//System.out.println(st1);
	//Stream ob=s.distinct();
	//ob.forEach(System.out::println);
	//System.out.println(ob);
	//System.out.println(obj);
	Optional <Integer>i=s.reduce((a,b)->a+b);
	System.out.println(i);
}
}
