package practice;

public class DataObjectGeneric<T> {
	private T t;
	public DataObjectGeneric(T t){
	this.t=t;	
	}
public T getObject()
{
	return this.t;
}
public static void main(String args[])
{
	DataObjectGeneric <Integer> iObj= new DataObjectGeneric <Integer> (54);
	System.out.println(iObj.getObject());
	DataObjectGeneric <String> sObj= new DataObjectGeneric <String> ("Samanvi");
	System.out.println(sObj.getObject());
}
}
