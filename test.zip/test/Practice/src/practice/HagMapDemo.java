package practice;

public class HagMapDemo {

}
