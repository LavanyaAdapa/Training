package prod;

public class Product {

}
