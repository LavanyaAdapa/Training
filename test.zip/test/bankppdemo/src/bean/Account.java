package bean;

public class Account {
private int accNo;
private static double balance=0.0;
private String name;
AccountType accountType;
public Account()
{
	
}
public Account(int accNo,String name,AccountType accountType)
{
	this.accNo=accNo;
	this.name=name;
	this.accountType=accountType;
}
public int getaccNo() {
	return accNo;
}
public void setaccNo(int accNo) {
	accNo = accNo;
}
public static double getBalance() {
	return balance;
}
public static void setBalance(double balance) {
	Account.balance = balance;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public AccountType getAccountType() {
	return accountType;
}
public void setAccountType(AccountType accountType) {
	this.accountType = accountType;
}
@Override
public String toString() {
	return "Account [accNo=" + accNo + ", name=" + name + ", accountType=" + accountType + "]";
}


}
