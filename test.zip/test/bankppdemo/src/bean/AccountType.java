package bean;

public enum AccountType {
SAVINGSACCOUNT,CURRENTACCOUNT
}
