package dao;

import java.util.HashMap;
import bean.Account;
import bean.AccountType;

public class BankData implements BankDataIntf {
	public static HashMap<Integer,Account>set=new HashMap<Integer,Account>();
	public void storeDetails()
	{
		Account ac=new Account(1,"Ahana",AccountType.CURRENTACCOUNT);
		Account ac2=new Account(2,"Bhanu",AccountType.SAVINGSACCOUNT);
		Account ac3=new Account(3,"Chitra",AccountType.CURRENTACCOUNT);
		Account ac4=new Account(4,"Dolly",AccountType.SAVINGSACCOUNT);
		set.put(1,ac);
		set.put(2,ac2);
		set.put(3,ac3);
		set.put(4,ac4);
		
	}
	public void retrieveDetails()
	{
		storeDetails();
		for(int i=0;i<set.size();i++)
		{
			System.out.println(set.get(i).toString());
		}
	
	}
	
}

