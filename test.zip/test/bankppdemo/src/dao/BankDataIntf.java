package dao;

public interface BankDataIntf {
public void storeDetails();
public void retrieveDetails();
}
