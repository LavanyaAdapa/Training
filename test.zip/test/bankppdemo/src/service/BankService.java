package service;

import java.util.Scanner;

import bean.Account;
import bean.AccountType;
import dao.BankData;

public class BankService implements BankServiceIntf{
	BankService bs;
	static int x,y,z;
	BankData bd=new BankData();
	public Account createAccount()
	{
		Scanner sc=new Scanner(System.in);
		Account ac1=new Account();
		System.out.println("Enter account number");
		int accNo=sc.nextInt();
				System.out.println("Enter account holder name:");
				String accName=sc.next();
				System.out.println("Account Type:");
				String accType=sc.next();
				BankData bd=new BankData();
				Account ac2=new Account(accNo,accName,AccountType.valueOf(accType));
				BankData.set.put(2654,ac2);
				System.out.println(ac2);
				return ac2;
			
	}
	
	
	public double showBalance(Account a)
	{
		return a.getBalance();
	}
	public double depositAmount(Account ac,double amount)
	{
		x++;
		Double balance=ac.getBalance();
		amount=amount+balance;
		ac.setBalance(amount);
		return ac.getBalance();
	}
	public double withDrawAmount(Account ac,double amount)
	{
		y++;
		Double balance=ac.getBalance();
		if(balance<amount)
		{
			System.out.println("Balance is not sufficient");
		}
		else
		{
			amount=balance-amount;
			ac.setBalance(amount);
		}
		return ac.getBalance();
	}
	public String fundTransaction(Account a1,Account a2,double amount)
	{
		z++;
		Double balance=a1.getBalance();
		Double balance1=a2.getBalance();
		if(balance>=amount)
		{
			balance=balance-amount;
			balance1=balance1+amount;
		}
		else
		{
			System.out.println("Balance is not sufficient");
		}
		System.out.println(a1);
		a1.setBalance(balance);
		a2.setBalance(balance);
		System.out.println(a1);
		System.out.println(a2);
		return "Transaction completed successfully";
		
	}
	public void printTransaction(Account a)
	{
		System.out.println("Deposit done by:"+x+"times");
		System.out.println("withDraw done by:"+y+"times");
		System.out.println("fundTransaction done by:"+z+"times");
		System.out.println("Transaction done by:"+a.getBalance());
}
}