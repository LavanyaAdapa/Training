package service;
import bean.Account;
public interface BankServiceIntf {
public double showBalance(Account a);
public double  depositAmount(Account ac,double amount);
public double withDrawAmount(Account ac,double amount);
public String fundTransaction(Account a1,Account a2,double amount);
public void printTransaction(Account ac);
}
