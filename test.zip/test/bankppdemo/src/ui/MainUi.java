package ui;
import bean.Account;
import bean.AccountType;
import service.BankService;
import java.util.Scanner;
public class MainUi {
public static void main(String args[])
{
	BankService bs=new BankService();
	
	for(;;)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("1.Create Account");
		System.out.println("2.Show Balance");
		System.out.println("3.Deposit Amount");
		System.out.println("4.Withdraw");
		System.out.println("5.Fund Transfer");
		System.out.println("6.Print Transaction");
		System.out.println("7.Exit");
		System.out.println("Enter your choice:");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:
			bs.createAccount();
			System.out.println("Account is created:");
			break;
		
			
		}
		
	}
}
}
