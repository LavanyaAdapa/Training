package mockito.test;


import static org.junit.jupiter.api.Assertions.*;
import  org.junit.jupiter.api.Test;


import mockito.ja.SampleMockitoJava;
import static org.mockito.Mockito.*;
public class SampleMockitoJavaTest {
@Test
void Test()
{
	SampleMockitoJava smObj=mock(SampleMockitoJava.class);
	when(smObj.sum(3,2)).thenReturn(5);
	assertTrue(smObj.sum(3,2)==5);
}
}
