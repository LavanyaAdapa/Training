package com.cg.eis.dao;

import java.util.List;

import com.cg.eis.bean.Employee;

public class EmployeeInsuranceDao implements EmployeeInsuranceDaoInterface {
	@Override
	public String addEmployee(Employee employee) {
		String insuranceScheme="";
		if (employee.getSalary()>=40000.0  && employee.getDesignation().equals("Manager")) {
            insuranceScheme+="Scheme A";
		}
        else if((employee.getSalary() >= 20000.0 && employee.getSalary() < 40000.0) && employee.getDesignation().equals("Programmer")) {
            insuranceScheme+="Scheme B";
        }
        else if((employee.getSalary() > 5000.0 && employee.getSalary() < 20000.0) && employee.getDesignation().equals("System Associate")) {
            insuranceScheme+="Scheme C";
        }
        else if(employee.getSalary()<5000 && employee.getDesignation().equals("Clerk")) {
            insuranceScheme+="No Scheme";
        }
		employeeList.add(employee);
		return insuranceScheme;
	}

	@Override
	public List<Employee> getEmployees() {
		return employeeList;
	}
	
	
}
