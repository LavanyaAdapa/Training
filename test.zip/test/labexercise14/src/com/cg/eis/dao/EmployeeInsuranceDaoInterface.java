package com.cg.eis.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.eis.bean.Employee;

public interface EmployeeInsuranceDaoInterface {
	List<Employee> employeeList=new ArrayList<>();
	public String addEmployee(Employee employee);
	public List<Employee> getEmployees();
}

