package com.cg.eis.exception;

public class EmployeeInsuranceException extends Exception {
	public EmployeeInsuranceException(String message) {
		super(message);
	}
}
