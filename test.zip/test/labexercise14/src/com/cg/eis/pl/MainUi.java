package com.cg.eis.pl;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeInsuranceException;
import com.cg.eis.service.EmployeeInsuranceService;

public class MainUi {
	public static void main(String[] args) {
		boolean continueValue = false;
		String continueChoice = "";
		Scanner scanner =null;
		EmployeeInsuranceService service = new EmployeeInsuranceService();
		do {
			System.out.println("Welcome to Employee Medical Insurance Scheme");
			System.out.println("1) Add Employee");
			System.out.println("2) Get All Employees");
			System.out.println("3) Exit");
			boolean choiceFlag = false;
			int choice = 0;
			do {
				System.out.println("Enter your choice:");
				try {
					scanner = new Scanner(System.in);
					choice = scanner.nextInt();
					int empId = 0;
					boolean employeeIDFlag = false;
					switch (choice) {
					case 1:
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter employee Id:");
							try {
								empId = scanner.nextInt();
								service.validateId(empId);
								employeeIDFlag = true;
							} catch (InputMismatchException e) {
								employeeIDFlag = false;
								System.err.println("Id should be in digits");
							} catch (EmployeeInsuranceException e) {
								employeeIDFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!employeeIDFlag);
						boolean employeeNameFlag=false;
						String empName="";
						do{
							scanner=new Scanner(System.in);
							System.out.println("Enter employee name:");
							try{
								empName = scanner.next();
								service.validateName(empName);
								employeeNameFlag=true;
							}catch(EmployeeInsuranceException e) {
								employeeNameFlag=false;
								System.err.println(e.getMessage());
							}
						}while(!employeeNameFlag);
						boolean employeeSalaryFlag=false;
						double empSalary=0;
						do{
							scanner=new Scanner(System.in);
							System.out.println("Enter employee salary:");
							try{
								empSalary = scanner.nextDouble();
								service.validateSalary(empSalary);
								employeeSalaryFlag=true;
							}
							catch(InputMismatchException e) {
								employeeSalaryFlag=false;
								System.err.println("Salary should be in digits");
							}catch(EmployeeInsuranceException e) {
								employeeSalaryFlag=false;
								System.err.println(e.getMessage());
							}
						}while(!employeeSalaryFlag);
						System.out.println("Enter employee designation:");
						String empDesignation = scanner.next();
						Employee employee = new Employee(empId, empName, empSalary, empDesignation, null);
						String insuranceScheme = "";
						try {
							insuranceScheme = service.addProduct(employee);
						} catch (EmployeeInsuranceException e) {
							System.out.println(e.getMessage());
						}
						System.out.println("your insurance scheme is:" + insuranceScheme);
						break;
					case 2:
						List<Employee> employee1 = new ArrayList<>();
						try {
							employee1 = service.getEmployees();
						} catch (EmployeeInsuranceException e) {
							System.out.println(e.getMessage());
						}
						System.out.println(employee1);
						break;
					case 3:
						System.exit(0);
						break;
					default:
						System.out.println("input should be 1/2/3");
						choiceFlag = false;
						break;
					}
				} catch (InputMismatchException e) {
					choiceFlag = true;
					System.err.println("input should be digits only");
				}
				do {
					System.out.println("Do you want to continue [Yes/No]:");
					continueChoice = scanner.next();
					if (continueChoice.equalsIgnoreCase("yes")) {
						continueValue = true;
						break;
					} else if (continueChoice.equalsIgnoreCase("no")) {
						System.out.println("Thank You");
						choiceFlag=true;
						continueValue = true;
					} else {
						System.out.println("Enter yes or no only");
						continueValue = false;
					}
				} while (!continueValue);
			} while (!choiceFlag);
		} while (!continueValue);
		scanner.close();
	}
}
