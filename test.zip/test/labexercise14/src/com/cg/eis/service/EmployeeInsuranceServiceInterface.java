package com.cg.eis.service;

import java.util.List;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeInsuranceException;

public interface EmployeeInsuranceServiceInterface{
	public String addProduct(Employee employee) throws EmployeeInsuranceException;
	public List<Employee> getEmployees() throws EmployeeInsuranceException;
	public boolean validateId(int empId) throws EmployeeInsuranceException;
	public boolean validateDesignation(String designation) throws EmployeeInsuranceException;
	public boolean validateName(String name) throws EmployeeInsuranceException;
	public boolean validateSalary(double salary) throws EmployeeInsuranceException;
}
