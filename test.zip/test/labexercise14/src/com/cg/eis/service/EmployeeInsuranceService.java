package com.cg.eis.service;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

 

import com.cg.eis.bean.Employee;
import com.cg.eis.dao.EmployeeInsuranceDao;
import com.cg.eis.exception.EmployeeInsuranceException;

 

public class EmployeeInsuranceService implements EmployeeInsuranceServiceInterface
{
    EmployeeInsuranceDao EisDao=new EmployeeInsuranceDao();
    public boolean validateName(String name) throws EmployeeInsuranceException{
        Pattern namePattern=Pattern.compile("[A-Z]{1}[a-z]{5,}");
        Matcher matcher=namePattern.matcher(name);
        if(matcher.matches())
            return true;
        else 
            return false;
    }
    public boolean validateDesignation(String designation) throws EmployeeInsuranceException{
        Pattern designationPattern=Pattern.compile("[A-Z]{1}[a-z]{1,}");
        Matcher matcher=designationPattern.matcher(designation);
        if(matcher.matches())
            return true;
        else 
            return false;
    }
    public boolean validateId(int id) throws EmployeeInsuranceException{
        String input1=String.valueOf(id);
        Pattern inputPattern=Pattern.compile("[0-9]");
        Matcher matcher=inputPattern.matcher(input1);
        if(matcher.matches())
            return true;
        else 
            return false;
    }
    public boolean validateSalary(double salary) throws EmployeeInsuranceException{
        return true;
    }
    public String addProduct(Employee employee) throws EmployeeInsuranceException{
        return EisDao.addEmployee(employee);
    }

 

    public List<Employee> getEmployees() throws EmployeeInsuranceException{
        return EisDao.getEmployees();
    }
}