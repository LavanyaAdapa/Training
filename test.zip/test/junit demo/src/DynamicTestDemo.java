import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.DynamicTest.dynamicTest;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;

public class DynamicTestDemo {
@TestFactory
List<DynamicTest>dynamicTestDemo()
{
	return Arrays.asList(
		dynamicTest("Simple Dynamic Test ",()->assertTrue(true)),	
		dynamicTest("Exception Executable ",()->assertTrue(true)),
		dynamicTest("Simple Dynamic Test2 ",()->assertTrue(true))
		);	
}
}
