
public class MathUtils {
public int multiply(int num1,int num2)
{
int mul=num1*num2;
return mul;
}
}
