import static org.junit.Assert.assertEquals;
import static org.junit.Assume.assumeTrue;
import static org.junit.jupiter.api.Assumptions.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.RepetitionInfo;
import org.junit.jupiter.api.Test;
@DisplayName("Math Testig")
public class AdditionTest {
	 @RepeatedTest (4)   
	 void testAdd(RepetitionInfo repetitionInfo)   
	 {    
		 System.out.println("@RepeatedTest @"+repetitionInfo.getCurrentRepetition());
		 assertEquals(0,repetitionInfo.getTotalRepetitions());
		/* Addition a=new Addition();       
	boolean serverStatus=false;
	 assumeTrue(serverStatus);  */
	 
	 } 
	/* @RepeatedTest(4)    
	 void testAdd1() 
	 {   
		 System.out.println("@RepeatedTest Simple Example2");
		 Addition a=new Addition();       
		 boolean serverStatus=true;         
		 assumeFalse(serverStatus);  
		
	 }*/
}
