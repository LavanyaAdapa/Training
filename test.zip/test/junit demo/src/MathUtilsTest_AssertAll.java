import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertAll;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
public class MathUtilsTest_AssertAll {
	MathUtils mathUtilsObj;
	@BeforeAll
	static void initClass()
	{
		System.out.println("Before All");
	}
	@BeforeEach
	void init()
	{
		MathUtils mathUtilsObj=new MathUtils();
		System.out.println("Before each");
	}
	@AfterAll
	static void display()
	{
		System.out.println("After All");
	}
	@AfterEach
	void res()
	{
		
		System.out.println("After Each");
	}
@Test
void testMultiply1(){
	MathUtils mathUtilsObj=new MathUtils();
	assertAll(
			()->assertEquals(6,mathUtilsObj.multiply(2,3)),
			()->assertEquals(20,mathUtilsObj.multiply(4,5))
			);
	
}

@Test
void testMultiply(){
	MathUtils mathUtilsObj=new MathUtils();
	assertAll(
			()->assertEquals(6,mathUtilsObj.multiply(2,3)),
			()->assertEquals(20,mathUtilsObj.multiply(4,5))
			);
	
}
}
