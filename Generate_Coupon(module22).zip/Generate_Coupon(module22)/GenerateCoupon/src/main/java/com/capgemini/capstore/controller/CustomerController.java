package com.capgemini.capstore.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.bean.Coupon;
import com.capgemini.capstore.exceptions.CouponNotFoundException;
import com.capgemini.capstore.service.CouponService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/coupon")
public class CustomerController {

	@Autowired
	CouponService service;

	
	
	@PostMapping(value="/create", consumes="application/json")
	public Coupon createcoupon(@RequestBody Coupon coupon)   {
		return service.createCoupon(coupon);
	}
	
	@GetMapping("/showDetails/{couponId}")
	public Coupon couponDetails(@PathVariable Long couponId) throws CouponNotFoundException {
		System.out.println("hi");
		return service.couponDetails(couponId);
	}
}
