package com.capgemini.capstore.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.bean.Coupon;
import com.capgemini.capstore.dao.CouponDao;
import com.capgemini.capstore.exceptions.CouponNotFoundException;

@Service
public class CouponServiceImplementation implements CouponService{

	@Autowired
	CouponDao Dao;
	@Override
	
	public Coupon createCoupon(Coupon coupon) {
	//Dao.save(coupon);
		return Dao.save(coupon);
	}

	@Override
	public Coupon couponDetails(Long couponId) throws CouponNotFoundException {
		if (!Dao.findById(couponId).isPresent())
		{
			throw new CouponNotFoundException("Invalid coupon number!!!");
		}
		else 
		{
			return Dao.findById(couponId).get();
		}
	}


}
