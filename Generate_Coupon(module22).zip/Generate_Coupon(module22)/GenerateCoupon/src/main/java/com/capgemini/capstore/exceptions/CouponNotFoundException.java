package com.capgemini.capstore.exceptions;

@SuppressWarnings("serial")
public class CouponNotFoundException extends Exception {

	public CouponNotFoundException() {
		super();
	}	
		public CouponNotFoundException(String msg) {
			super(msg);
		}
}
