package com.capgemini.capstore.service;



import com.capgemini.capstore.bean.Coupon;
import com.capgemini.capstore.exceptions.CouponNotFoundException;

public interface CouponService {

	Coupon createCoupon( Coupon coupon) ;

	Coupon couponDetails(Long couponId)throws CouponNotFoundException;

	
}
