package com.capgemini.capstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GenerateCouponApplication {

	public static void main(String[] args) {
		SpringApplication.run(GenerateCouponApplication.class, args);
	}

}
