import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from '../../node_modules/rxjs';
import { Coupon } from './coupon';


@Injectable({
  providedIn: 'root'
})
export class CouponsService {

  constructor(private http:HttpClient) { }

  generateCoupon(coupon) {
   return this.http.post<Coupon>("http://localhost:7070/coupon/create",coupon);
  }

}




  