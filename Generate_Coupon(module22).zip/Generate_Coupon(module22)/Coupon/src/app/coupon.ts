export class Coupon {
	
	couponId: number;
    couponCode: string;
	discountPercent: number;
	generationDate: string;
	expiryDate: string;
}