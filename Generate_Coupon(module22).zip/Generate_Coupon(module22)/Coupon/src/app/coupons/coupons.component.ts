import { Component, OnInit } from '@angular/core';
import { Coupon } from '../coupon';
import { CouponsService } from '../coupons.service';

@Component({
  selector: 'app-coupons',
  templateUrl: './coupons.component.html',
  styleUrls: ['./coupons.component.css']
})
export class CouponsComponent implements OnInit {

  constructor(private service:CouponsService) { }

  coupon:Coupon=new Coupon();

  ngOnInit() {
  }

  generateCoupon(data) {
    alert(data.couponCode);
    this.coupon.couponCode=data.couponCode;
    this.coupon.discountPercent=data.discountPercent;
    this.coupon.generationDate=data.generationDate;
    this.coupon.expiryDate=data.expiryDate;
    this.service.generateCoupon(this.coupon).subscribe(data => console.log(data), error => console.log(error));
  }

}
