import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { FormsModule } from'@angular/forms'
import { HttpClientModule } from'@angular/common/http'



import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CouponsComponent } from './coupons/coupons.component';

@NgModule({
  declarations: [
    AppComponent,
    CouponsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [CouponsComponent]
})
export class AppModule { }
