//The regular expression just checks for an occurrence of the string regex

import java.util.regex.*;
public class RegexDemo1 {
public static void main( String args[]){
	String text    ="Welcome to Java regex ";

	String regex = ".*regex.*";

	boolean matches = Pattern.matches(regex, text);

	System.out.println("matches = " + matches);
}
}
