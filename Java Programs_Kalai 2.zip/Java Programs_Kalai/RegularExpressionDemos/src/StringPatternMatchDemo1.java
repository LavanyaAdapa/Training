import java.util.regex.*;
public class StringPatternMatchDemo1 {
public static void main(String args[]){
	String s1="Hello everybody";
	String s2="Hello everybody";
	boolean result= Pattern.matches(s1,s2);
	System.out.println(result);
	
	System.out.println(s1.matches(s2));
}
}
