
public class PhoneNumberValidation {

	public static void main(String args[]) {
		String phoneNum="123-456-1111";
		if (phoneNum.matches( "[1-9]{3}-[1-9]{3}-[1-9]{4}" ))
			System.out.println("Valid Number");
		else 
			System.out.println("Invalid number");
	}
}
