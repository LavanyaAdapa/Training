//matcher.start() will return the (starting position - 1) value
//matcher.end() will return end position
import java.util.regex.*;
public class RegexDemo2 {
	public static void main(String args[]) {
		String text    ="If You Are Working On Something That You Really Care About, You Don�t Have To Be Pushed. The Vision Pulls You.";

		String regex = "You";

		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(text);

		int count = 0;
		while(matcher.find()) {
		    count++;
		    System.out.println("found: " + count + " : "
		            + matcher.start() + " - " + matcher.end());
		}

	}

}
