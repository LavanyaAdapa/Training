
public class NameValidation {
	
	public static void main(String args[]) {
		//String name="Kalaiselvi";
		//String name="Kalaiselvi1";
		//String name="kalaiselvi";
		//String name="kalai selvi";
		String name="KALAISELVI";
		if(name.matches( "[A-Z][a-zA-Z]*" ) )
			System.out.println("valid name");
		else 
			System.out.println("Invalid name");
	}

}
