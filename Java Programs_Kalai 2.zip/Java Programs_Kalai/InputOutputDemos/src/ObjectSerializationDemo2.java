import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class ObjectSerializationDemo2 {
  public static void main(String[] args) throws Exception {
	  ObjectReadWrite obj1 = new ObjectReadWrite("A","Hi");
	  ObjectReadWrite obj2 = new ObjectReadWrite("B","Welcome");
	  ObjectReadWrite obj3 = new ObjectReadWrite("V","Bye");
    ObjectOutputStream objectOut = new ObjectOutputStream
    		(new BufferedOutputStream(
        new FileOutputStream("D:/JunkObjects.bin")));
    objectOut.writeObject(obj1); // Write object
    objectOut.writeObject(obj2); // Write object
    objectOut.writeObject(obj3); // Write object
    objectOut.close(); // Close the output stream

    ObjectInputStream objectIn = null;
    int objectCount = 0;
    ObjectReadWrite object = null;

    objectIn = new ObjectInputStream(new BufferedInputStream(new FileInputStream(
        "d:/JunkObjects.bin")));

    // Read from the stream until we hit the end
    while (objectCount < 3) {
      object = (ObjectReadWrite) objectIn.readObject();
      objectCount++;
      System.out.println(object);
    }
    objectIn.close();

  }
}

