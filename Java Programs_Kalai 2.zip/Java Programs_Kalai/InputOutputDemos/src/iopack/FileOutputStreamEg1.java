package iopack;

public class FileOutputStreamEg1 {

}
