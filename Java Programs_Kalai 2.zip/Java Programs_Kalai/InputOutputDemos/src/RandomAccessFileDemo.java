import java.io.*;
public class RandomAccessFileDemo {
	
	public void readRAF()throws IOException{
		try{
		RandomAccessFile rafObj=new 
				RandomAccessFile("d:/consoledemo.txt","r");
		String a;
		while((a=rafObj.readLine())!=null){
			System.out.println(a);
		
		}	
		rafObj.close();
	}catch(Exception e){
		System.out.println(e);
	}
	}
		public void writeRAF()throws IOException{
			try{
				RandomAccessFile rafObj=new 
						RandomAccessFile("d:/filet.txt","rw");
				rafObj.writeChars("Hello Everybody");
				
				rafObj.close();				
			}catch(IOException e){
			System.out.println(e);	
			}
		}
public static void main(String args[])throws IOException{
	RandomAccessFileDemo rafdObj=new RandomAccessFileDemo();
	//rafdObj.readRAF();
	rafdObj.writeRAF();
}
}
