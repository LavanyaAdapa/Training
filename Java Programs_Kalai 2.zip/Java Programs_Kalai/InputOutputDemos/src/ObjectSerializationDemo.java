import java.io.*;  
import java.util.*;
class Student implements Serializable{  
 int id;  
 String name;  
 public Student(int id, String name) {  
  this.id = id;  
  this.name = name;  
 }  
 public String toString(){
	 return id+" "+name;
 }
}  
public class ObjectSerializationDemo {
static void writeData(Student sObj)
{
	try{
	FileOutputStream fout=new FileOutputStream("d:/f.txt");  
	  ObjectOutputStream out=new ObjectOutputStream(fout);  
	  out.writeObject(sObj);  
	  out.close();
	  fout.close();
	}catch(Exception e){
		System.out.println(e);
	}
	  System.out.println("success");  
	
}
static void readData(){

	try{
	FileInputStream fIn=new FileInputStream("d:/f.txt");  
	  ObjectInputStream in=new ObjectInputStream(fIn);
		Student sobj=(Student) in.readObject();	 
		System.out.println(sobj);
	}
	catch(Exception e){
		System.out.println(e);
	}
}
public static void main(String args[]){
	Student st=new Student(1,"Jack");
	Student st1=new Student(2,"Jack");
	Student st2=new Student(1,"Jack");
	writeData(st);
	writeData(st1);
	writeData(st2);
	readData();
	
}
}

