import java.io.*;
public class BufferedReaderDemo1 {
	public static void main(String args[]) 
		    throws IOException
	{
		//BufferedReader reader =   new BufferedReader(new InputStreamReader(System.in));
		
		InputStreamReader r=new InputStreamReader(System.in);
		BufferedReader reader =new BufferedReader(r);
		
     String text =null;
     System.out.println("Type end to terminate");
    	 while((text=reader.readLine())!=null) {
    		 if(text.equals("end"))
    			 System.exit(0);
    		 else
    			 System.out.println(text);
    	 }
    	 
     
      
	}
}
