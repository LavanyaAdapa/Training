import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class ObjectWriteDemo {
	public static void main(String[] args) throws Exception {
		ObjectReadWrite obj1 = new ObjectReadWrite("A","Hi");
		ObjectReadWrite obj2 = new ObjectReadWrite("B","Welcome");
		ObjectReadWrite obj3 = new ObjectReadWrite("V","Bye");
	    ObjectOutputStream objectOut = 
	    		new ObjectOutputStream(new BufferedOutputStream(
	        new FileOutputStream("D:/JunkObjects.txt")));

	    objectOut.writeObject(obj1); // Write object
	    objectOut.writeObject(obj2); // Write object
	    objectOut.writeObject(obj3); // Write object
	    objectOut.close(); // Close the output stream
	}
}
