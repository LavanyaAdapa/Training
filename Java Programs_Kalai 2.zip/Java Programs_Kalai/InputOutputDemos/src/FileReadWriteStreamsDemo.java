import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.*;
public class FileReadWriteStreamsDemo {
	public static void main(String st[])throws Exception{
		String s="d:\\fileread.txt";
		String s1="d:\\buffer.java";
		int i;
		String sr;
		FileInputStream fr=new FileInputStream(s);
		FileOutputStream bw=new FileOutputStream(s1);
		
		while((i=fr.read())!=-1){
			bw.flush();
			bw.write(i);
			
	}
	}

}
