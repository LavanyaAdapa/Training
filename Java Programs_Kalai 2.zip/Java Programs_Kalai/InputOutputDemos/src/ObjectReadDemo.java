import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class ObjectReadDemo {
public static void main(String args[])throws Exception{
	ObjectInputStream objectIn = null;
    int objectCount = 0;
    ObjectReadWrite object = null;

    objectIn = new ObjectInputStream
    		(new BufferedInputStream(new FileInputStream(
        "d:/JunkObjects.txt")));

    // Read from the stream until we hit the end
    while (objectCount < 3) {
      object = (ObjectReadWrite) objectIn.readObject();
      objectCount++;
      System.out.println(object);
    }

    objectIn.close();
}
}
