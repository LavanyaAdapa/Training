import java.io.*;
public class FileReadWriteDemo {
	public static void main(String st[])throws Exception{
		String s="d:\\fileread.txt";
		String s1="d:\\buffer.java";
		int i;
		FileReader fr=new FileReader(s);
		BufferedWriter bw=new BufferedWriter(new FileWriter(s1,true));
		
		while((i=fr.read())!=-1){
			bw.flush();
			bw.write(i);
			
	}
		fr.close();
		bw.close();
		System.out.println("File write complete");
	 				
}
}
