import java.util.*;
class NegativeAgeException extends Exception{
	NegativeAgeException(){
		System.out.println("Negative Age");
	}
	NegativeAgeException(String a){
		System.out.println("NegativeAgeException:"+a);
		
	}
}
public class ThrowExceptionDemo {
	public static void main(String args[]) throws Exception{
		Scanner sc=new Scanner(System.in);
		//NegativeAgeException ae=new NegativeAgeException();
		System.out.println("Enter age:");
		int age=sc.nextInt();
		//try{
		if(age<0)
			throw new NegativeAgeException("Age can not be Negative");
			//throw ae;
		else
			System.out.println("Age:"+age);
		//}catch(Exception e){
			//System.out.println();
			//System.out.println(e);
		//}
		System.out.println("main method ends");
		
	}

}
