import java.util.*;
public class MultipleCatch_FinallyDemo {
	public static void main(String args[]){
		try{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter value1:");
		String s1=sc.next();
		int a=Integer.parseInt(s1);
		System.out.println("Enter value2:");
		int b=sc.nextInt();
		int result=a/b;
		  Object x = new Integer(0);
		  System.out.println((String)x);
		}catch(NumberFormatException nf){
			System.out.println("Catch Block 1:"+nf);
		}
		catch(ArithmeticException ae){
			System.out.println("Catch Block 2:"+ae);
		}
		catch(Exception ae){
			System.out.println("Catch Block 3:"+ae);
		}
		finally{
			System.out.println("Finally block");
		}
		System.out.println("Remaining block of code");

	}

}
