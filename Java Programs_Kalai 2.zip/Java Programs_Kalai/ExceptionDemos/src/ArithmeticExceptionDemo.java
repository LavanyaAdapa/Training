

public class ArithmeticExceptionDemo {
	
	static void calculate() {
		int a=10/0;
	}

public static void main(String args[]) {
	
	
		
		  try { 
			 int a=10/10; 
			 calculate(); 
			  } 
		  catch (ArithmeticException e) {
		  System.out.println("Exception raised "+e); 
		  }
		  finally {
			  System.out.println("finally");
		  }
		 
	
	System.out.println("Main method ends");
}
	
}

