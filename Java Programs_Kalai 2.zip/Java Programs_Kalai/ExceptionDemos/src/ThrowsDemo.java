
public class ThrowsDemo {
	public static void main(String arg[])throws Exception {
		int a=190;
		try {
		if(a>90)
			throw new Exception();
		}catch (Exception e) {
			System.out.println(e);
		}
		
		System.out.println("Main end");
	}

}
