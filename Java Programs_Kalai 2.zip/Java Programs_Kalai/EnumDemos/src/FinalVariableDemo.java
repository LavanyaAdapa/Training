
public class FinalVariableDemo {
final int a=90;
public static void main(String args[]){
	FinalVariableDemo obj=new FinalVariableDemo();
	//obj.a=56;
}
}
