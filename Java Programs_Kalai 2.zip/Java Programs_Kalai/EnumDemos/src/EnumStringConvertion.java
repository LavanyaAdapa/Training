enum Color{
	RED,GREEN,BLUE,ORANGE
}

public class EnumStringConvertion {
	
	static public void enumTOString(Color c) {
		String colorName=c.name();
		System.out.println(colorName);
	}
	
	static public void stringToEnum(String str) {
		Color c=Color.valueOf(str);
		System.out.println(c);
		
	}
	
	public static void main(String args[]) {
		enumTOString(Color.RED);
		stringToEnum("GREEN");
	}

}
