enum TrafficSignal
{ 
	
    RED,GREEN,ORANGE ;
	
} 
public class EnumTest1 
{ 
    TrafficSignal color; 
    public EnumTest1(TrafficSignal color) 
    { 
        this.color = color; 
    } 
    public void selectColor() 
    { 
        switch (color) 
        { 
        case RED: 
            System.out.println("Wait"); 
            break; 
        case GREEN: 
            System.out.println("GO"); 
            break; 
        case ORANGE: 
            System.out.println("SLOW DOWN"); 
            break; 
        default: 
            System.out.println("Not in the list."); 
            break; 
        } 
    }  
    public static void main(String[] args) 
    { 
        EnumTest1 etObj=
        	new EnumTest1(TrafficSignal.RED);
        etObj.selectColor(); 
    } 
} 