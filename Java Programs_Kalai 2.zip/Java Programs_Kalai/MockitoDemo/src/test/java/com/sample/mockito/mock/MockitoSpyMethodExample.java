package com.sample.mockito.mock;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import org.mockito.Spy;
public class MockitoSpyMethodExample {
	/*
	@Spy 
	List<String> spyOnList1 = new ArrayList<String>();
	*/
	@Test
	void test() {
		List<String> list = new ArrayList<String>();
		List<String> spyOnList = spy(list);
		
		
		
		spyOnList.add("A");
		assertEquals(1, spyOnList.size());
		assertEquals("A", spyOnList.get(0));

		spyOnList.add("E");
		assertEquals(2, spyOnList.size());
		assertEquals("E", spyOnList.get(1));

		when(spyOnList.size()).thenReturn(10);
		assertEquals(10, spyOnList.size());
	}
}
