package mypack;

public interface HelloWorld {
	
	    public void greet();
	    public void greetSomeone(String someone);
	

}
