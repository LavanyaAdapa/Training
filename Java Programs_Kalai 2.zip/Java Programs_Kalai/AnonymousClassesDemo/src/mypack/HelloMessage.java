package mypack;

public interface HelloMessage {
	 public void greetSomeone(String someone);
}
