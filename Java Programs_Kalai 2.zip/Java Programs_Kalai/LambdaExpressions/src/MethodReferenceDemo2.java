
 class Employee{
	 String name;
	 Integer age;
	 //Constructor of employee
	 public Employee(String name, Integer age){
	  this.name=name;
	  this.age=age;
	 }
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	 
	}
@FunctionalInterface
interface EmployeeFactory{
	 public abstract Employee getEmployee(String name, Integer age);
	}

public class MethodReferenceDemo2 {
	
		
public static void main(String args[]){
	
	// Lambda Expression
	 EmployeeFactory ef=(v,s)->{
	    	Employee s1=new Employee(v,s);
	    	return s1;
	    };
	Employee x=ef.getEmployee("Jake", 52);
	
	// Method reference
    
    EmployeeFactory empFactory=Employee::new;
    Employee emp= empFactory.getEmployee("John", 25);
    
    System.out.println(emp.getName()+"-"+emp.getAge());
    
    
   
    


}
}
