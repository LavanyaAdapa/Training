

class Hello {

	protected String s;
	
	public Hello(String str){
		this.s = str;
	}
	public void sayHello(){
		System.out.println(s);
	};
	
	
}
public class AnonymusInnerClassDemo1 {
public static void main(String[] args) {
		
		//anonymous class inside method
		Hello h = new Hello("abc") {

			@Override
			public void sayHello() {
				System.out.println("Hello anonymous class "+s);
			}
		};
		
		h.sayHello();
		
	}

}

