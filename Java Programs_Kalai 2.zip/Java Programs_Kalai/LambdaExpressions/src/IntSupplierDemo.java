import java.util.function.*;
public class IntSupplierDemo {
public static void main(String args[]){
	
		IntSupplier supplier1 = () -> Integer.MAX_VALUE;
		System.out.println("Max value"+supplier1.getAsInt());
		IntSupplier supplier2 = () -> Integer.MIN_VALUE;
		System.out.println("Min Value:"+supplier2.getAsInt());
		int a=5;
		int b=10;
		IntSupplier supplier3=()-> a*b;
		System.out.println(supplier3.getAsInt());
		/*compare() the value 0 if x == y; 
		 * a value less than 0 if x < y; 
		 * and a value greater than 0 if x > y
		 */
		IntSupplier supplier4=()->Integer.compare(a,b);
		System.out.println(supplier4.getAsInt());
	}
}

