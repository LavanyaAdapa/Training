import java.util.function.*;
public class BooleanSupplierDemo {
	public static void main(String args[]){
		BooleanSupplier supplier1 = () -> (false);
		System.out.println(supplier1.getAsBoolean());
		String s1="Java";
		String s2="Java";
		BooleanSupplier supplier2 = () -> s1.equals(s2);
		System.out.println(supplier2.getAsBoolean());
	}
	}

