enum Color{
	RED,GREEN,BLUE,YELLOW
	
	
}
interface StateChangeListener{
	public void onStateChange();
}
class StateChangeOwner{
	static Color newColor;
	public void addStateChangeListener(StateChangeListener scl) 
	{
		scl.onStateChange();
	}
	
}
class SampleState extends StateChangeOwner{
	
	void changeColor(Color color) {
		System.out.println("change color:"+color);
		addStateChangeListener(new StateChangeListener(){
			public void onStateChange() {
				
				System.out.println("onStateChange"+color);
				StateChangeOwner.newColor=color;;
				
				
		}
		
		});
		
		
		System.out.println(StateChangeOwner.newColor);
	}
	
	
}
class TestSampleState{
	
	void displayColor() {
		System.out.println("display color");
		System.out.println(StateChangeOwner.newColor );
	}
	
}
public class AnonymusInnerClassDemo {
	
	public static void main(String args[]) {
		SampleState ssObj=new SampleState();
		TestSampleState tssObj=new TestSampleState();
		
		ssObj.changeColor(Color.GREEN);
		
		tssObj.displayColor();
	}

}
