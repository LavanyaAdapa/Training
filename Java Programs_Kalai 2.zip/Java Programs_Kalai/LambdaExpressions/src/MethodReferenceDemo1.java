import java.util.function.BiFunction;
import java.util.function.Function;

public class MethodReferenceDemo1 {
	public static void main(String args[]) {
	System.out.println(String.valueOf(65));
    // Using  a  lambda  expression
    Function<Integer, String> func1  = 
    		x -> String.valueOf(x);
    System.out.println("Function "+func1.apply(10));
    
    // Using  static method  reference
    
    Function<Integer, String> func2  = String::valueOf;
    System.out.println(func2.apply(10));
    String s=func2.apply(16);
    
    
    // Using static method reference
    
    
    BiFunction<Integer, Integer, Integer> func4 = Integer::sum;
    System.out.println(func4.apply(2, 3));
    
    
    
    
}
}
