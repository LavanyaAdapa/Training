import java.util.function.*;
public class BiPredicateDemo {
	public static void main(String[] args){
	      BiPredicate<Integer, String> condition = (i,s)-> i>20 && s.startsWith("R");
	      System.out.println(condition.test(10,"Rax"));
	      System.out.println(condition.test(30,"Kim"));
	      System.out.println(condition.test(30,"Ray"));
	    } 
}
