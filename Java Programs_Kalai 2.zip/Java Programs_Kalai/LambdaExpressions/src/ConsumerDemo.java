import java.util.function.*;
public class ConsumerDemo {
public static void main(String args[]){
	Consumer<String> consumerStr=s->{
		System.out.println(s);
	};
	consumerStr.accept("Hello Java.");
	consumerStr.accept("Hello World.");
	
	Consumer<Integer> consumerInt=i->{
		System.out.println("Integer value="+i);
	};
	consumerInt.accept(5);
	consumerInt.accept(8);
	consumerInt.accept(8);
}
}

