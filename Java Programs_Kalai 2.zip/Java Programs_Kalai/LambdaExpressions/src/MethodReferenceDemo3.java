import java.util.function.*;
class Sample{
	static void display(String s) {
		System.out.println(s);
	}
	void print(String d) {
		System.out.println(d);
	}
}
public class MethodReferenceDemo3 {
	public static void main(String args[]) {
		Sample obj=new Sample();
		Consumer<String> c1=Sample::display;
		c1.accept("Static Method Refernce");
		
		Consumer<String> c2=obj::print;
		c2.accept("Non static Method reference");
	}

}
