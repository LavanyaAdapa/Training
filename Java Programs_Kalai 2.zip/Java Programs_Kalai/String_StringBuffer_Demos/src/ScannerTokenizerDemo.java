import java.util.*;
public class ScannerTokenizerDemo {
	public static void main(String args[]) {
					 
		      System.out.print("Enter a string: ");
		 
		      Scanner sc = new Scanner(System.in);
		      String str = sc.nextLine();
		 
		      StringTokenizer st = new StringTokenizer(str);
		      while (st.hasMoreElements()) {
		         System.out.println(st.nextElement());
		      }
		 
		      sc.close();
		   }
	}

