//Unordered and UnSorted Set
//No duplicate values
import java.util.*;
public class HashSetDemo {
	public static void main(String args[]){
		HashSet hs=new HashSet();
		Integer iObj=5;
		HashSet<String> hs1=new HashSet<String>();
		
		hs.add(iObj);
		hs.add(1);
		hs.add(1);
		hs.add(1.2);
		hs.add("Hello");
		hs.add(9.7);
		hs.add(hs1);
		hs.add(new String("Hi"));
		
		System.out.println(hs);
		
		
		  Iterator i=hs.iterator(); 
		  while(i.hasNext())
		  { 
			  System.out.println(i.next()); 
			  }
		 
	}

}
