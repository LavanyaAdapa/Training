import java.util.*;
public class LinkedHashMapDemo {
	
	public static void main(String args[]) {
		LinkedHashMap lhmObj=new LinkedHashMap();
		
		lhmObj.put(1, null);
		lhmObj.put(2, null);
		lhmObj.put(null, null);
		lhmObj.put(null,"hello");
		lhmObj.put(null,"h");
		
		System.out.println(lhmObj);
	}

}
