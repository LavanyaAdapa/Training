import java.util.*;
public class PriorityQueueDemo {
	
	public static void main(String args[]) {
		
		PriorityQueue<String> pqObj=new PriorityQueue<String>();
		
		pqObj.add("Reema");
		pqObj.add("Sheetal");
		pqObj.add("Anjali");
		pqObj.add("Sheetal");
		
		System.out.println(pqObj);
	}

}
