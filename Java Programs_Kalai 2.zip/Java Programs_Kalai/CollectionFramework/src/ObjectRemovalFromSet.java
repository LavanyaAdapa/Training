import java.util.HashSet;
import java.util.Set;

class Emp{
	int empId;
	String empName;
	Emp(int eId, String eName){
		empId=eId;
		empName=eName;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	@Override
	public String toString() {
		return "Emp [empId=" + empId + ", empName=" + empName + "]";
	}
	
	
}
public class ObjectRemovalFromSet {
	static Set<Emp> s=new HashSet<Emp>();
	static void addObject(Emp obj) {
		s.add(obj);
		
	}
	static void removeObject(Emp obj) {
		s.remove(obj);
		
	}
	public static void main(String args[]) {
		Emp e1=new Emp(1,"AAA");
		Emp e2=new Emp(2,"BBB");
		
		addObject(e1);
		addObject(e2);
		System.out.println(s);
		
		Emp e3=e2;
		removeObject(e3);
		System.out.println(s);
		
		
	}

}
