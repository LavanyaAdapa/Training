import java.util.*;
public class ArrayListDemo {
	public static void main(String args[]) {
		ArrayList alObj=new ArrayList(2);
		alObj.add(1);
		alObj.add(2);
		System.out.println(alObj);
		System.out.println(alObj.size());
		alObj.add(3);
		
		System.out.println(alObj);
		System.out.println(alObj.size());
	}

}
