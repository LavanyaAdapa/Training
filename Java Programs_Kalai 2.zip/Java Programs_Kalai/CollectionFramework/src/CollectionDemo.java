import java.util.*;
class Accounts{
	int accountId;
	double deposit;
	double withdrawl;
	double balance;
	Accounts(){
		
	}
	
	public Accounts(int accountId, double balance) {
		this.accountId = accountId;
		this.balance = balance;
	}

	public Accounts(double deposit, double withdrawl, double balance) {
		this.deposit = deposit;
		this.withdrawl = withdrawl;
		this.balance = balance;
	}

	Accounts(int accountId, double deposit, double withdrawl, double balance) {
		this.accountId = accountId;
		this.deposit = deposit;
		this.withdrawl = withdrawl;
		this.balance = balance;
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public double getDeposit() {
		return deposit;
	}
	public void setDeposit(double deposit) {
		this.deposit = deposit;
	}
	public double getWithdrawl() {
		return withdrawl;
	}
	public void setWithdrawl(double withdrawl) {
		this.withdrawl = withdrawl;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Accounts [accountId=" + accountId + ", deposit=" + deposit + ", withdrawl=" + withdrawl + ", balance="
				+ balance + "]";
	}
	
	
}
class AccountsDAO{
	static List<Accounts> depositList=new ArrayList<Accounts>();
	static List<Accounts> withdrawlList=new ArrayList<Accounts>();
	static Map<Integer,Accounts> accountsMap=new HashMap<Integer,Accounts>();
	
	void addAccountsDAO(Accounts aObj) {
		
		accountsMap.put(aObj.getAccountId(), aObj);
		
				
	}
	
	void depositDAO(Accounts aObj) {
	depositList.add(aObj);
	}
	
	void withDrawlDAO(Accounts aObj) {
		withdrawlList.add(aObj);
		}

	Accounts displayAccountsDAO(int accountId) {
		Accounts aobM = accountsMap.get(accountId);

		return aobM;

	}
	List<Double> displayDepositDAO(int accountId) {
		Iterator<Accounts> dIterator=depositList.iterator();
		List<Double> deposit=new ArrayList<Double>();
		 while (dIterator.hasNext()) { 
			  Accounts d=dIterator.next();
			  
			  if(d.getAccountId()==accountId) {				  
			  deposit.add(d.getDeposit());
			  }
		 }
		 return deposit;
	}
	
	List<Double> displayWithdrawDAO(int accountId){
Iterator<Accounts> wIterator=withdrawlList.iterator();
		List<Double> withdrawl=new ArrayList<Double>();
		  while (wIterator.hasNext()) { 
			  Accounts w=wIterator.next(); 
			  if(w.getAccountId()==accountId) {
			  withdrawl.add(w.getWithdrawl());
			  }
			  
		  }
		  return withdrawl;
	}
	
}

class AccountsService {
	AccountsDAO adaoObj;

	AccountsService() {
		adaoObj = new AccountsDAO();
	}

	void accountsService(Accounts aObj) {
		adaoObj.addAccountsDAO(aObj);

	}

	void depositService(Accounts aObj, double dAmount) {
		aObj.setDeposit(dAmount);
		aObj.setBalance(aObj.getBalance() + dAmount);
		adaoObj.addAccountsDAO(aObj);
		adaoObj.depositDAO(aObj);

	}

	void withdrawlService(Accounts aObj, double dAmount) {
		aObj.setWithdrawl(dAmount);
		aObj.setBalance(aObj.getBalance() - dAmount);
		adaoObj.addAccountsDAO(aObj);
		adaoObj.withDrawlDAO(aObj);

	}

	Accounts displayAccountsService(int accountId) {
		Accounts aObj = adaoObj.displayAccountsDAO(accountId);
		return aObj;

	}

	List<Double> displayWithdrawService(int accountId) {
		return adaoObj.displayWithdrawDAO(accountId);
	}

	List<Double> displayDepositService(int accountId) {
		return adaoObj.displayDepositDAO(accountId);
	}
}
	


class AccountsView{
	Accounts acc1;
	Accounts acc2;
	Accounts acc3;
	AccountsService asObj;
	
	AccountsView(){
		asObj=new AccountsService();
		
	}
	void generateAccounts() {
		acc1=new Accounts(1,5000);
		acc2=new Accounts(2,17000);
		acc3=new Accounts(3,8000);
		
		asObj.accountsService(acc1);
		asObj.accountsService(acc2);
		asObj.accountsService(acc3);
	}
	
	void doDeposit(double dAmt ) {
		asObj.depositService(acc1, dAmt);	
	}
void dowithDrawl(double dAmt ) {
	
	asObj.withdrawlService(acc1, dAmt);
	
	
}
void displayAccounts(int accountId) {
	Accounts aDetails=asObj.displayAccountsService(accountId);
	List<Double> depositList=asObj.displayDepositService(accountId);
	List<Double> withdrawList=asObj.displayWithdrawService(accountId);
	
	System.out.println("Account ID:"+aDetails.getAccountId());
	System.out.println("All the deposit:"+depositList);
	System.out.println("All the withdrawls:"+withdrawList);
	System.out.println("Balance:"+aDetails.getBalance());
	
	
}
	
}
public class CollectionDemo {
	
	public static void main(String args[]) {
		AccountsView avObj=new AccountsView();
		avObj.generateAccounts();
		avObj.doDeposit(2000);
		avObj.dowithDrawl(1000);
		avObj.doDeposit(3000);
		avObj.doDeposit(2000);
		avObj.dowithDrawl(1000);
		avObj.doDeposit(3000);
		avObj.displayAccounts(1);
		
	}

}
