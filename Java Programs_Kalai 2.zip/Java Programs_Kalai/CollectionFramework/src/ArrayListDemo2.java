//Ordered but not Sorted
//Maintains the order of insertion.
//Allows duplicates 
// Vector class is similar to ArrayList but has synchronized methods

import java.util.*;
public class ArrayListDemo2 {
public static void main(String args[]){
	Integer iObj=new Integer(5);
	ArrayList al=new ArrayList();
	
	al.add(new Float(1.2));
	al.add(new String("hello"));
	al.add(new Double(9.7));
	al.add(iObj);
	System.out.println(al);
	System.out.println(al.get(3));
	System.out.println(al.indexOf(iObj));
	

	
}
}
