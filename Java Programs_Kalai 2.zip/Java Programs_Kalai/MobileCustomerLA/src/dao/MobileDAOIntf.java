package dao;
import bean.Mobile;
public interface MobileDAOIntf {
Mobile[] retriveMobileDetails();
void storeMobileDetails(Mobile mObj);
	
}
