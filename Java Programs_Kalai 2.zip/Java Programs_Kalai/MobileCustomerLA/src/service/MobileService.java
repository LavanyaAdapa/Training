package service;

import bean.Mobile;
import dao.MobileDAO;
public class MobileService implements MobileServiceIntf {
static MobileDAO mdaoObj=new MobileDAO();
	public Mobile[] retriveMobileService() {
		return mdaoObj.retriveMobileDetails();
		
	}
	public void storeMobileService(Mobile mObj) {
		mdaoObj.storeMobileDetails(mObj);
	}
	
}
