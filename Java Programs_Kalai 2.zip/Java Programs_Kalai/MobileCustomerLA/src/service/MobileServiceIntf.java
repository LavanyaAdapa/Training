package service;

import bean.Mobile;

public interface MobileServiceIntf {
	Mobile[] retriveMobileService();
	void storeMobileService(Mobile mObj);
}
