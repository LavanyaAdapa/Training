
public class TrafficSignalDemo extends Thread {
	Thread t;
	int a=0,b=1;
	String green="GREEN";
	String red="RED";
	String yellow="YELLOW";
	
	TrafficSignalDemo(String name){
		setName(name);
		start();
	
		
	}
	void displayBackgroundDetails(){
		
		String sellItems[]={"ball", "dolls", "hangings"};
		String sellerName[]={"Kim", "Jack","Mike"};
		int sellItemRange=sellerName.length;
		int sellerNamerange=sellerName.length;
		double dSI=Math.random()*sellItemRange;
		int sellItemRandomVal=(int)dSI;
		double dSN=Math.random()*sellItemRange;
		int sellerNameRandomVal=(int)dSN;
		if(a==0 && b==1)
		{
		System.out.println(sellerName[sellItemRandomVal]+" is selling "+sellItems[sellerNameRandomVal]);
		}
		try
		  {
		   Thread.sleep(3000);
		  }
		  catch(Exception e)
		  {
		   e.printStackTrace();
		  }
		displayBackgroundDetails();
	}
	void printSignal(){
		
		if(a==0)//REDSIGNAL
		{
			System.out.println(red);
			b=1;
			try
			  {
			   Thread.sleep(3000);
			  }
			  catch(InterruptedException  e)
			  {
			   e.printStackTrace();
			  }
			a=1;
		}
		else if(a==1)//YELLOWSIGNAL
		{
		System.out.println(yellow);
		try
		  {
		   Thread.sleep(1000);
		  }
		  catch(Exception e)
		  {
		   e.printStackTrace();
		  }
			a=2;
		}
		if(a==2)//GREENSIGNAL
		{
			System.out.println(green);
			try
			  {
			   Thread.sleep(6000);
			  }
			  catch(InterruptedException e)
			  {
			   e.printStackTrace();
			  }
				a=0;
		}
		 
		 printSignal();
	}
	public void run(){
		String threadName=Thread.currentThread().getName();
		System.out.println(threadName);
		if(threadName.equals("TrafficSignal")){
		
		printSignal();
		}
		if(threadName.equals("BackgroundDetails"))
		displayBackgroundDetails();
	}
public static void main(String args[]){
	TrafficSignalDemo ts1=new TrafficSignalDemo("TrafficSignal");
	TrafficSignalDemo ts2=new TrafficSignalDemo("BackgroundDetails");
	
	
}
}
