
public class ThreadClassDemo extends Thread {
	public void run() {
		for(int i=0;i<5;i++) {
			System.out.println(getName()+":"+i);
		}
	}
	
	public static void main(String args[]) {
		ThreadClassDemo tcd1=new ThreadClassDemo();
		ThreadClassDemo tcd2=new ThreadClassDemo();
		tcd1.setName("Hello");
		tcd1.start();
		tcd2.setName("Hey");
		tcd2.start();
		
		
	}
	
	

}
