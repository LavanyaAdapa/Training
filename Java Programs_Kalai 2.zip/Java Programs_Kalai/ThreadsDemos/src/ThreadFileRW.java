

	import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
	class FileReadWrite{
		
		void fileReadWrite() throws IOException {
			String s="d:\\fileread.txt";
			String s1="d:\\twrite.txt";
			int i;
			FileReader fr=new FileReader(s);
			BufferedWriter bw=new BufferedWriter(new FileWriter(s1,true));
			int counter = 1;
			while((i=fr.read())!=-1){
				
				System.out.print((char)i);
				bw.flush();
				bw.write(i);
				if(counter ==10) {
					System.out.println("10 characters copied");
					counter = 1;
				}
				counter++;
				
				
				
				
				
		}
			System.out.println("File write complete");
			fr.close();
			bw.close();
		}
		}
		
		public class ThreadFileRW extends Thread{
			FileReadWrite frw=new FileReadWrite();
			public void run() {
				try {
				frw.fileReadWrite();
				}catch(Exception e) {
					System.out.println(e);
				}
			}
		public static void main(String st[])throws Exception{
			ThreadFileRW tfObj=new ThreadFileRW();
			tfObj.start();
		 				
	}


}
