class SampleThread extends Thread{
	public void run() {
		for(int i=1;i<5;i++) {
			System.out.println(this);
		System.out.println(getName()+" "+i);
		}
	}
}
class SampleThreadImp implements Runnable{
	public void run() {
		for(int i=1;i<5;i++) {
			System.out.println("Sample Thread Imp Run Method"+i);
			}
	}
	
}
public class ThreadDemo {
	public static void main(String args[]) throws InterruptedException {
		SampleThread st1=new SampleThread();
		st1.setName("ST1 Thread");
		SampleThread st2=new SampleThread();
		st2.setDaemon(true);
		st2.setName("ST2 Thread");
		st2.start();
		
		st1.start();
		for(int i=1;i<5;i++) {
			System.out.println("Main Method"+i);
		}
		System.out.println("Main Method Ends");
		
		
		
	}

}
