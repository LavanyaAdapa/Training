
public class MusicPlayTask implements Runnable {
	public void run(){
		System.out.println(
				"MusicPlayTask is executing");
		try{
			Thread.sleep(6000);
		}catch(Exception e){
			System.out.println(e);
		}
		System.out.println("MusicPlayTask "
				+ "is resumed after sleep");
	}
}
