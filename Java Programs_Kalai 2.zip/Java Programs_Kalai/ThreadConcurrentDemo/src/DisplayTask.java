import java.util.concurrent.*;
public class DisplayTask implements Callable {
	String message;
	DisplayTask(String message){
		this.message=message;
	}
public String call(){
	return message;
}
}
