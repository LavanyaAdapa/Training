
public class CopyTask implements Runnable{
	public void run(){
		System.out.println(""
				+ "CopyTask is executing");
		try{
			Thread.sleep(6000);
		}catch(Exception e){
			System.out.println(e);
		}
		System.out.println(""
				+ "CopyTask is resumed after sleep");
		
	}

}
