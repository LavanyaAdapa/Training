class Demo{
	
}

public class NonGenericDemo {
	public static void main(String args[]){
		DataObject obj1=new DataObject();
		String s1=new String("Hello");
		obj1.setObject(s1);
		DataObject obj2=new DataObject();
		Integer i1=1;
		obj2.setObject(i1);
		
		DataObject obj3=new DataObject();
		Demo d=new Demo();
		obj3.setObject(d);
		
		String s2=(String)obj1.getObject();
		Integer i2=(Integer)obj2.getObject();
		
		System.out.println(i2);
		System.out.println(s2);
		
	}

}
