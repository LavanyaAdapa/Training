
public class DataObjectGeneric<T> {
	private T t;

	   public void setObject(T t) {
	      this.t = t;
	   }

	   public T getObject() {
	      return t;
	   }

}
