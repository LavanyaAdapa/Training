class MyClass<X> {
  X ob;
  MyClass(X o) {
    ob = o;
  }
  X getob() {
    return ob;
  }
}
class MySubclass<T, V> extends MyClass<T> {
  V ob2;
 
  MySubclass(T o, V o2) {
	  
    super(o);
    ob2 = o2;
  }
  V getob2() {
    return ob2;
  }
}
public class GenericInheritance {
	  public static void main(String args[]) {
		    MySubclass<String, Integer> x = 
		    new MySubclass<String, Integer>("Input: ", 9);
		    System.out.print(x.getob());
		    System.out.println(x.getob2());
		    MySubclass<String, Double> y = 
		    new MySubclass<String, Double>("Value: ", 99.90);
		    System.out.print(y.getob());
		    System.out.println(y.getob2());
		  }
}
