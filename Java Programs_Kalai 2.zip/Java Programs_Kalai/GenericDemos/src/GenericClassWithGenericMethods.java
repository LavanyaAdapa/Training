
public class GenericClassWithGenericMethods {
	public static void main(String[] args) {
		DataObjectGeneric<Integer> integerBox = 
				new DataObjectGeneric<Integer>();
		DataObjectGeneric<String> stringBox = new DataObjectGeneric<String>();
		//DataObject<Student> sObj=new DataObject<Student>()
	    
	      integerBox.setObject(1);
	      stringBox.setObject(new String("Hello World"));

	      Integer i1=integerBox.getObject();
	      System.out.println("Integer Value :"+ integerBox.getObject());
	      System.out.println("String Value :"+stringBox.getObject());
	   }

}
