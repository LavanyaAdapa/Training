import java.util.*;
public class GenericRestrictionDemo {
	
	static public void setSuperObject(ArrayList <? super Number> list) {
		
			
	}
	static public void setExtendsObject(ArrayList <? extends Number> list) {
		
	}
	public static void main(String args[]) {
		ArrayList<Number> alObj1=new ArrayList<Number>();
		alObj1.add(1);
		alObj1.add(1.1);
		
		ArrayList<Integer> alObj2=new ArrayList<Integer>();
		alObj1.add(1);
		alObj1.add(2);
		
		ArrayList<Object> alObj3=new ArrayList<Object>();
		alObj3.add(1);
		alObj3.add("Hello");
		
		setSuperObject(alObj3);
		setSuperObject(alObj1);
		//setSuperObject(alObj2); //error
		
		
		setExtendsObject(alObj1);
		setExtendsObject(alObj2);
		//setExtendsObject(alObj2); //error
		
		
	}

}
