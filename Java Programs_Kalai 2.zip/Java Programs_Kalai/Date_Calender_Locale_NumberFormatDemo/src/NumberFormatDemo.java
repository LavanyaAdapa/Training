// country name- language code -country code  
//Denmark -  da -DK
//France -  fr -FR
//India - IN -en


import java.text.NumberFormat;
import java.util.Locale;

public class NumberFormatDemo {
	public static void main(String args[]) {
		Locale locale = new Locale("da", "DK");

		NumberFormat numberFormat = NumberFormat.getInstance(locale);
		System.out.println(numberFormat.format(10000099));
		
		
		NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(locale);
 		System.out.println(currencyFormat.format(100.999));
	}

}
