import java.time.LocalDate;
import java.util.Calendar;

public class CalendarDemo {
	public static void main(String args[]) 
    { 
		//Old Way
        Calendar c = Calendar.getInstance(); 
        System.out.println("The Current Date is:" + c.getTime());
        System.out.println("Current Calendar's Year: " + c.get(Calendar.YEAR));
        System.out.println("Current Calendar's Month: " + c.get(Calendar.MONTH));// Jan - 0
        System.out.println("Current Calendar's Day: " + c.get(Calendar.DATE)); 
        System.out.println("Current MINUTE: " + c.get(Calendar.MINUTE)); 
        System.out.println("Current SECOND: " + c.get(Calendar.SECOND));
        
        
        //JDK 8
        System.out.println();
        LocalDate currentDate = LocalDate.now(); 
        System.out.println("Day of Week :"+currentDate.getDayOfWeek()); 
        System.out.println("Day of Month:"+currentDate.getDayOfMonth()); 
        System.out.println("Day of the year:"+currentDate.getDayOfYear());
        System.out.println("Month:"+currentDate.getMonth()); 
        System.out.println("Year:"+currentDate.getYear());
        
        
    } 
}
