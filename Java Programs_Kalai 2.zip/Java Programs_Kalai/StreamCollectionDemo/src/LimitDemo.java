import java.util.*;
import java.util.stream.*;
public class LimitDemo {
	public static void main(String args[]) {
	List<Integer> numList=new ArrayList<Integer>();
	numList.add(34);
	numList.add(54);
	numList.add(13);
	numList.add(34);
	numList.add(34);
	numList.add(34);
	
	Stream<Integer> s=numList.stream();
	Stream<Integer>s1=s.limit(2);
	
	System.out.println(numList);
	
	s1.forEach(System.out::println);
	}

}
