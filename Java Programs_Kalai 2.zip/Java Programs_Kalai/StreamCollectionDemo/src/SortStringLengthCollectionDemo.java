import java.util.*;

import java.util.stream.*;


public class SortStringLengthCollectionDemo {
	public static void main(String args[]) {
		List<String> nameList=new ArrayList<String>();
		nameList.add("Jack");
		nameList.add("Kathy");
		nameList.add("Mickey");
		nameList.add("Jim");
		nameList.add("Kim");
		System.out.println(nameList);
		Comparator<String> c1=(s1,s2)->{
			int l1=s1.length();
			int l2=s2.length();
			if(l1>l2)
				return 1;
			else if(l1<l2)
			return -1;
			else
				return s1.compareTo(s2);
		};
		List<String> lengthSortedList1=nameList.stream().sorted(c1).collect(Collectors.toList());
		System.out.println("Ascending:"+lengthSortedList1);
		Comparator<String> c2=(s1,s2)->{
			int l1=s1.length();
			int l2=s2.length();
			if(l1>l2)
				return -1;
			else if(l1<l2)
			return 1;
			else
				return s2.compareTo(s1);
		};
		List<String> lengthSortedList=nameList.stream().sorted(c2).collect(Collectors.toList());
		System.out.println("Descending:"+lengthSortedList);
		
	}

}
