import java.util.*;
import java.util.stream.*;
public class SortCollectionDemo {
public static void main(String args[]) {
	List<Integer> markList=new ArrayList<Integer>();
	markList.add(67);
	markList.add(78);
	markList.add(45);
	markList.add(56);
	markList.add(90);
	System.out.println(markList);
	List<Integer> sortedList1=markList.stream().sorted().collect(Collectors.toList());
	System.out.println(sortedList1);
	List<Integer> sortedList2=markList.stream().sorted((i1,i2)->i1.compareTo(i2)).collect(Collectors.toList());
	System.out.println(sortedList2);
	List<Integer> sortedList3=markList.stream().sorted((i1,i2)->-i1.compareTo(i2)).collect(Collectors.toList());
	System.out.println(sortedList3);
	List<Integer> sortedList4=markList.stream().sorted((i1,i2)->(i1>i2)?-1:(i1<i2)?1:0).collect(Collectors.toList());
	System.out.println(sortedList4);
	
}
}
