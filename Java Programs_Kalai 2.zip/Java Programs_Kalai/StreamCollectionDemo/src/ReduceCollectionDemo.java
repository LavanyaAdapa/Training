import java.util.*;
import java.util.function.BinaryOperator;
import java.util.stream.*;
public class ReduceCollectionDemo {
	public static void main(String ars[]) {
		// 1st number inclusive last number exclusive
		OptionalInt reducedInt=IntStream.range(1,5).
				reduce((a,b)->a+b);  
		System.out.println(reducedInt.getAsInt());
		 
		 
	}

}
