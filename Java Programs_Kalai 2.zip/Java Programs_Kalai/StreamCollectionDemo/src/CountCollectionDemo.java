import java.util.*;
import java.util.stream.*;
public class CountCollectionDemo {
	public static void main(String args[]) {
		List <Integer> markList=new ArrayList<Integer>();
		markList.add(56);
		markList.add(78);
		markList.add(67);
		markList.add(45);
		markList.add(39);
		System.out.println(markList);
		long failedCount=markList.stream().filter(i->i<50).count();
		System.out.println(failedCount);
	}

}
