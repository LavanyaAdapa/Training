import java.util.*;
import java.util.stream.*;
public class MinMaxFromCollectionDemo {
	public static void main(String args[]) {
		List<Integer> numberList=new ArrayList<Integer>();
		numberList.add(3);
		numberList.add(32);
		numberList.add(21);
		numberList.add(13);
		numberList.add(45);
		numberList.add(89);
		numberList.add(45);
		System.out.println(numberList);
		
		Comparator<Integer> c1=(s1,s2)->s1.compareTo(s2);
		Comparator<Integer> c2=(s1,s2)->s2.compareTo(s1);
		
		List assSort=numberList.stream().sorted(c1).collect(Collectors.toList());
		System.out.println(assSort);
		
		List descSort=numberList.stream().sorted(c2).collect(Collectors.toList());
		System.out.println(descSort);
		
		int assMinNum=numberList.stream().min(c1).get();
		System.out.println(assMinNum);
		int assMaxNum=numberList.stream().max(c1).get();
		System.out.println(assMaxNum);
		int descMinNum=numberList.stream().min(c2).get();
		System.out.println(descMinNum);
		int descMaxNum=numberList.stream().max(c2).get();
		System.out.println(descMaxNum);
	}

}
