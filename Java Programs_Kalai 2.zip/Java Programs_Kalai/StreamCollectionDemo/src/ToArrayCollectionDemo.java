import java.util.*;
import java.util.stream.*;
import java.util.function.*;
public class ToArrayCollectionDemo {
	public static void main(String args[]) {
		List<Integer> numberList=new ArrayList<Integer>();
		numberList.add(118);
		numberList.add(25);
		numberList.add(51);
		numberList.add(190);
		
		Stream<Integer> s=numberList.stream();
		Integer iArr[]=s.toArray(Integer[]::new);
		
		Integer intArr[]=
				numberList.stream().toArray(Integer[]::new); //constructor reference
		
		for(Integer i:intArr)
			System.out.println(i); 
		
		System.out.println();
		
		Stream<Integer> sOf=Stream.of(intArr);
		sOf.forEach(System.out::println);
		
		
		
		Stream<Integer> s1= numberList.stream();
		
		s1.forEach(System.out::println);
		
		
		
	}
	
	

}
