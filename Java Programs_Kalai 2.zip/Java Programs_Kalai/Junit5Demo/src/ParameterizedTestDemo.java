
import java.util.stream.*;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import java.util.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;

enum ColorType{
	RED, GREEN,BLUE,ORANGE
}
public class ParameterizedTestDemo {
	@ParameterizedTest
	@ValueSource(ints = { 1, 2, 3 })
	void test_ValueSource(int i) {
		assertTrue(i < 5);
	}
	@ParameterizedTest
	@ValueSource(strings = { "1", "2", "3" })
	void test_ValueSource_String(String s) {
		assertTrue(Integer.parseInt(s) < 5);
	}
	
	@ParameterizedTest
	@EnumSource(ColorType.class)
	void test_EnumSource(ColorType et) {
		System.out.println(et);
	}
	
	@ParameterizedTest
	@MethodSource("ms")
	void test_MethodSource(String s) {
		assertNotNull(s);
	}

	static Stream<String> ms() {
		return Stream.of("A", "B");
	}
	
	@ParameterizedTest
	@CsvSource(delimiter=',', value= {"1,B","2,A"})
	void test_CsvSource(int i, String s) {
		assertTrue(3 > i);
		assertTrue(Arrays.asList("A","B").contains(s));
	}
	
	
}
