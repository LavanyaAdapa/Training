
public class Addition {

	public int add(int num1,int num2) {
		int sum =num1+num2;
		return sum;
	}
}
