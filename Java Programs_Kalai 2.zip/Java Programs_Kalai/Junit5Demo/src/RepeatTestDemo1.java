
import org.junit.jupiter.api.*;
public class RepeatTestDemo1 {
	
	@RepeatedTest(5)
	void test() {
		System.out.println("@RepeatedTest Simple Example");
	}
	
}
