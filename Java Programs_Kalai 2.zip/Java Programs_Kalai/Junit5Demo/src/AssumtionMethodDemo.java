import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assumptions.*;
public class AssumtionMethodDemo {
	String s1=new String("Hello");
	String s2=new String("Hello");
	String s3=s1;
	String s4=s2;
	String s5="Hi";
@Test
void testAssumeTrue(){
	
	assumeTrue(true);
	{
		assertSame(s1,s3);
	System.out.println("testAssumeTrue");
	}
}
@Test
void testAssumeFalse(){
	
	assumeFalse(false);
	{
		assertSame(s1,s3);
	System.out.println("testAssumeFalse");
	}
}
@Test
void testAssumingThat(){
	
	assumingThat(
			s1.equals(s2),
			() -> assertEquals(s1,s2)
	);
	
	System.out.println("testAssumeThat");
	
}


	

}
