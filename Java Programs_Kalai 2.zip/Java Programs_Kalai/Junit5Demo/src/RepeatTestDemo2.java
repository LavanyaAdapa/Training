
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.*;
public class RepeatTestDemo2 {
	@RepeatedTest(3)
	void repeatedTest(RepetitionInfo repetitionInfo) {
	System.out.println("Repetition #" + repetitionInfo.getCurrentRepetition());
	assertEquals(0, repetitionInfo.getTotalRepetitions());
	}

}
