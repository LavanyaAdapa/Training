
import org.junit.jupiter.api.*;


class StandardTest {

    @BeforeAll
    static void initAll() {
    	System.out.println("Before All");
    }

    @BeforeEach
    void init() {
    	System.out.println("Before Each");
    }

    @Test
    void succeedingTest() {
    	System.out.println("succeeding Test ");
    	
    }

    @Test
    void failingTest() {
    	System.out.println("failing test");
       
    }

    @Test
   
    void skippedTest() {
        
    	System.out.println("skippedTest");
    }

    @Test
    void abortedTest() {
    	System.out.println("abortedTest");
    }

    @AfterEach
    void tearDown() {
    	System.out.println("AfterEachh");
    }
    @AfterAll
    static void tearDownAll() {
    	System.out.println("After All");
    }

}

