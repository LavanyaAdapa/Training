package com.service;
import com.bean.*;
import com.dao.*;

public class EmployeeService {
	EmployeeDAO empDao=new EmployeeDAO();
	
	public void storeEmployeeData(Employee obj) {
		empDao.addEmployeeData(obj);
	}
	
	public Employee retriveEmployeeData() {
		return empDao.getEmployeeDetails();
	}

}
