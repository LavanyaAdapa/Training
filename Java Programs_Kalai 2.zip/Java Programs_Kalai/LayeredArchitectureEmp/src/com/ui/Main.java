package com.ui;

public class Main {
public static void main(String args[]) {
	EmployeeDetailsInput ediObj=new EmployeeDetailsInput();
	ediObj.setEmployeeDetails();
	ediObj.displayEmployeeDetails();
}
}
