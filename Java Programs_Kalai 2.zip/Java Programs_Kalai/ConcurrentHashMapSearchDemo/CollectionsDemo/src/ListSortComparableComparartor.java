import java.util.*;
class Employee implements Comparable<Employee> {

    private int id;
    private String name;
    private int age;
    private long salary;

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public long getSalary() {
        return salary;
    }

    public Employee(int id, String name, int age, int salary) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.salary = salary;
    }

    @Override
    public int compareTo(Employee emp) {
        //let's sort the employee based on an id in ascending order
        //returns a negative integer, zero, or a positive integer as this employee id
        //is less than, equal to, or greater than the specified object.
        return (this.id - emp.id);
    }

    @Override
    //this is required to print the user-friendly information about the Employee
    public String toString() {
        return "[id=" + this.id + ", name=" + this.name + ", age=" + this.age + ", salary=" +
                this.salary + "]";
    }

} 
class EmployeeComparatorByName implements Comparator<Employee> {

    @Override
    public int compare(Employee o1, Employee o2) {
        int flag;
        flag = o1.getName().compareTo(o2.getName());
        return flag;
    }

}
class EmployeeComparatorByAge implements Comparator<Employee> {

    @Override
    public int compare(Employee o1, Employee o2) {
        int flag = o1.getAge() - o2.getAge();
        return flag;
    }

}
public class ListSortComparableComparartor {
	public static void main(String args[]){
		
		Employee eObj1=new Employee(1,"Jack",23,45000); 
		Employee eObj2=new Employee(2,"Kate",53,65000);
		Employee eObj3=new Employee(3,"Jacky",43,55000); 
		Employee eObj4=new Employee(4,"Mate",50,60000);
		List<Employee> lObj=new LinkedList<Employee>();
		lObj.add(eObj1);
		lObj.add(eObj4);
		lObj.add(eObj3);
		lObj.add(eObj2);
		System.out.println(lObj);
		Collections.sort(lObj);
		System.out.println(lObj);
		Collections.sort(lObj,new EmployeeComparatorByName());
		System.out.println(lObj);
		Collections.sort(lObj,new EmployeeComparatorByAge());
		System.out.println(lObj);
		
	}
	

}
