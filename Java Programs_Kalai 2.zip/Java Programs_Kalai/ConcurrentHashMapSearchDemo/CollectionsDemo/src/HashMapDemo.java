//key & value pair
//unordered and unsorted
import java.util.*;

class A{
	int a=10;
	int b=20;
}
class B{
	String a="a";
	String b="b";
}
public class HashMapDemo {
	public static void main(String args[]){
		A aobj=new A();
		B bobj=new B();
		HashMap hs=new HashMap();
		hs.put(aobj,bobj);
		Set keys = hs.keySet();
		
	    Iterator itr = keys.iterator();
		A key;
	   B value;
	    while(itr.hasNext())
	    {
	        key = (A)itr.next();
	        value = (B)hs.get(key);
	        System.out.println(key + " - "+ value);
	    }
	
		
	}

}
