// Manipulation with LinkedList is faster
//Maintains the order of insertion.
//Allows duplicate values
//Ordered and Unsorted
import java.util.*;
public class LinkedListDemo {
public static void main(String args[]){
	Integer iObj=new Integer(5);
	LinkedList al=new LinkedList();
	al.add(new Integer(1));
	al.add(iObj);
	al.add(new Float(1.2));
	al.add(new String("hello"));
	al.add(new Double(9.7));
	al.add("hello");
	System.out.println(al);
	al.remove(1);
	
	System.out.println(al);
	
	
}
}
