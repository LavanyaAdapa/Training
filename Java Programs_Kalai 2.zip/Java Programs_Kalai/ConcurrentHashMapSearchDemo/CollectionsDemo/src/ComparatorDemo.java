import java.util.*;
class Company {
    private int num_of_employess;
    private String name;
    public Company(String name, int num_of_employess) {
        this.name = name;
        this.num_of_employess = num_of_employess;
    }
     
    public int getNumOfEmployess() {
        return this.num_of_employess;
    }
     
    public String getName() {
        return this.name;
    }
}
class SortCompanies implements Comparator<Company> {
    
    @Override
    public int compare(Company comp1, Company comp2) {        
        if(comp1.getNumOfEmployess()== comp2.getNumOfEmployess())
            return 0;
        else
            return comp1.getNumOfEmployess() > comp2.getNumOfEmployess() ? 1 : -1;
    }
}
public class ComparatorDemo {
	public static void main(String[] args) {
        Company comp1 = new Company("Company1", 20);
        Company comp2 = new Company("Company2", 15);
         
        SortCompanies sortCmp = new SortCompanies();
         
        int retval = sortCmp.compare(comp1, comp2);
        switch(retval) {
            case -1: {
                System.out.println("The " + comp2.getName() + " is bigger!");
                break;
            }
            case 1: {
                System.out.println("The " + comp1.getName() + " is bigger!");
                break;
            }
            default:
                System.out.println("The two companies are of the same size!");
        }
            }
}
