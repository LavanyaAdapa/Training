import java.util.*;
class Person implements Comparable<Person> { 
	private String name;
    private int age; 
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    } 
    public String getName() {
		return name;
	}
	
	public int getAge() {
		return age;
	}
    @Override
    public String toString() {
        return name+" "+age;
    }
    public int compareTo(Person per) {
        if(this.age == per.age)
            return 0;
        else
            return this.age > per.age ? 1 : -1;
    }
    
}
class PersonComparatorByName implements Comparator<Person> {

    @Override
    public int compare(Person o1, Person o2) {
        int flag;
        flag = o1.getName().compareTo(o2.getName());
        return flag;
    }
}
public class ComparableDemo {
	public static void main(String[] args) {
        Person e1 = new Person("Steve", 65);
        Person e2 = new Person("Adam", 60);
        LinkedList ll=new LinkedList();
        ll.add(e1);
        ll.add(e2);
        System.out.println(ll);
        Collections.sort(ll,new PersonComparatorByName());
        System.out.println(ll);
        Collections.sort(ll);
        System.out.println(ll);    
        
    }
}
