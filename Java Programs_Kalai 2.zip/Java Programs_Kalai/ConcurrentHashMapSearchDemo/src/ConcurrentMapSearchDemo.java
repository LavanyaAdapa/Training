import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedDeque;
public class ConcurrentMapSearchDemo {
public static void main(String args[]){
	ConcurrentHashMap<String, ConcurrentLinkedDeque<Operation>> userHash = new ConcurrentHashMap<>();
	HashFiller hashFiller = new HashFiller(userHash);

	Thread[] threads = new Thread[10];
	for (int i = 0; i < 10; i++) {
		threads[i] = new Thread(hashFiller);
		threads[i].start();
	}

	for (int i = 0; i < 10; i++) {
		try {
			threads[i].join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	System.out.print("Size:"+userHash.size());

	userHash.forEach(10, (user, list) -> {
		System.out.println(Thread.currentThread().getName()+":"+ user+":"+list.size());
	});

	userHash.forEachEntry(10, entry -> {
		System.out.println( Thread.currentThread().getName()+":"+entry.getKey()+":"+entry.getValue().size());
	});

	Operation op = userHash.search(10, (user, list) -> {
		for (Operation operation : list) {
			if (operation.getOperation().endsWith("1")) {
				return operation;
			}
		}
		return null;
	});

	System.out.println("The operation we have found is:"+ op.getOperation()+":"+ op.getUser()+":"+op.getTime());

	ConcurrentLinkedDeque<Operation> operations = userHash.search(10, (user, list) -> {
		if (list.size() > 10) {
			return list;
		}
		return null;
	});

	System.out.println("The user we have found is:"+operations.getFirst().getUser()+":"+operations.size()+"operations");
			

	int totalSize = userHash.reduce(10, (user, list) -> {
		return list.size();
	}, (n1, n2) -> {
		return n1 + n2;
	});

	System.out.println("The total size is:"+totalSize);

}
}

