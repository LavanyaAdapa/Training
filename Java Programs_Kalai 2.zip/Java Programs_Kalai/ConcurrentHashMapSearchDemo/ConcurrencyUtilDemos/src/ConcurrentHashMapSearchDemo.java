import java.util.concurrent.*;
public class ConcurrentHashMapSearchDemo {
public static void main(String args[]){
	ConcurrentHashMap<String,String> chm=new ConcurrentHashMap<String,String>();
	chm.put("A","Kune");
	chm.put("B","Mumbai");
	chm.put("C","Katna");
	String result=chm.search(10,(k,v)->
	v.startsWith("P")?"Contains":null);
	System.out.println(result);
	
	
}
}
