import java.util.*;
public class ArrayDequeDemo {
public static void main(String args[]){
	ArrayDeque adObj=new ArrayDeque();//default size 16 elements but grows in size when elements are added
	
	adObj.add("Hello");
	adObj.add("Greetings");
	adObj.add("Hi");
	System.out.println(adObj);
	adObj.addFirst("Welcome");
	System.out.println(adObj);
	
	Iterator i=adObj.iterator();
	//adObj.add("Hey");
	while(i.hasNext()){
		System.out.println(i.next());
	}
	
}
}
