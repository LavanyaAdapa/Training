import java.util.concurrent.ConcurrentHashMap;

public class ConcurrentHashMapReduceDemo {
	public static void main(String args[]){
ConcurrentHashMap<String,Integer> chm=new ConcurrentHashMap<String,Integer>();
	chm.put("A",1);
	chm.put("B",2);
	chm.put("C",3);
	chm.put("D",4);
	chm.reduce(10_000,(key,value)->
	chm.size(),(value1,value2)->
	Integer.max(value1,value2));

}
}
