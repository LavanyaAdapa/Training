import java.util.concurrent.ConcurrentHashMap;

public class ConcurrentHashMapForEachDemo {
public static void main(String args[]){
ConcurrentHashMap<String,String> chm=
new ConcurrentHashMap<String,String>();
	
	chm.put("A","Kune");
	chm.put("B","Mumbai");
	chm.put("C","Patna");
	
	chm.forEach((key,value)->{
		System.out.println(key+":"+value);
	});
	
	

}
}