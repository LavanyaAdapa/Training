
public class DemoTest {
public static void main(String args[]){
	int i=1;
	int x=1,y=2;
	int c=i<=1?x++:1;
	System.out.println(c);
}
}
