import java.sql.*;
public class PreparedStatementUpdateDemo {
public static void main(String args[]){
	Connection con;
	PreparedStatement pst;
	String uName="LLLL";
	int uId=101;
	try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","password");
		pst=con.prepareStatement("update user_info set name=? where id=?");
		pst.setString(1, uName);
		pst.setInt(2, uId);
		pst.executeUpdate();
		System.out.println("row updated");
	}catch(Exception e){
		System.out.println(e);
	}
}
}

