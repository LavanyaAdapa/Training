import java.sql.*;
public class Demo {
public static void main(String args[]){
	Connection con = null;
    Statement st = null;
    ResultSet rs = null;
	try{
		Class.forName("oracle.jdbc.driver.OracleDriver");    
		con=DriverManager.getConnection(  
		"jdbc:oracle:thin:@localhost:1521:xe","system","password");
		st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                ResultSet.CONCUR_UPDATABLE);
		 rs = st.executeQuery("select id, name from user_info");
		 int concurrency = rs.getConcurrency();
         if (concurrency == ResultSet.CONCUR_UPDATABLE){
        	 System.out.println("Updateable result");
        	 rs.absolute (2);
   		  rs.updateString("name","Jill");
   		  rs.updateRow();
         }
         else
        	 System.out.println("Not updateable");
	}catch(Exception e){
	System.out.println(e);
	}
}
}
