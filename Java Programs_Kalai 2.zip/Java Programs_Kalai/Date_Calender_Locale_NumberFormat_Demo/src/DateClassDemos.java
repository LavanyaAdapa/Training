import java.util.*;
/*Allocates a Date object and initializes it to represent the specified number of milliseconds since the standard base time known as "the epoch"
, namely January 1, 1970, 00:00:00 GMT.*/
public class DateClassDemos {
public static void main(String args[]){
	Date d1=new Date();
	Date d2=new Date(977999999999L);//January 1, 1970+milliseconds
	Date d3=new Date(999999675926L);
	Date d4=new Date(0L);
	
	System.out.println(d1);
	System.out.println(d2);
	System.out.println(d3);
	System.out.println(d4);
	if(d3.before(d1))
		System.out.println("True");
	else
		System.out.println("False");
	if(d3.after(d1))
		System.out.println("True");
	else
		System.out.println("False");
}
}
